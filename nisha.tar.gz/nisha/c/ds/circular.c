#include"header1.h"
void rev_print1(ST *,ST *); // using recursion reverse printing
void rev_print2(ST *);  // using 2 for loop reverse printing
void rev_print3(ST *); // using double pointer reverse printing
void rev_data(ST *);   //using 2 for loop reverse data
void rev_data1(ST *);  //using double pointer reverse data
void rev_link(ST **);  // using double pointer reverse link
void rev_link1(ST **);  // using 2 for loop reverse link
void del_node(ST **);  //  delete a particular node
int  count_node(ST *);
void add_begin(ST **);
void add_end(ST **);
void add_middle(ST **ptr);
void print_node(ST *);
main()
{
	ST *headptr=0;
	char ch;
	do
	{
//		add_begin(&headptr);
//		add_end(&headptr);
		add_middle(&headptr);
		printf("do u want to add more nodes\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');
//	rev_print1(headptr,headptr);
//	rev_print2(headptr);
//	rev_print3(headptr);
//	rev_data(headptr);
//	rev_data1(headptr);
//	rev_link(&headptr);
	rev_link1(&headptr);
	print_node(headptr);
}//main

///////////////////

void rev_link1(ST **ptr)
{
	ST *temp,*temp1,*temp2;
	int i,j;
	int count=count_node(*ptr);
	for(i=0;i<count;i++)
	{
		temp=*ptr;
		for(j=0;j<count-1-i;j++)
			temp=temp->next;
		if(i==0)
		{
			temp->next=temp->pre;
			temp->pre=0;
			temp2=temp;
		}
		else if(i==count-1)
		{
			temp->pre=temp->next;
			*ptr=temp2;
			temp->next=*ptr;
		}
		else
		{
			temp1=temp->next;
			temp->next=temp->pre;
			temp->pre=temp1;
		}
	}
}

///////////////////

void rev_link(ST **ptr)
{
	ST *temp=*ptr;
	int node=count_node(*ptr),i;
	ST **p=malloc(sizeof(ST *)*node);
	for(i=0;i<node;i++)
	{
		p[i]=temp;
		temp=temp->next;
	}
	for(i=1;i<node;i++)
	{
		if(i==node-1)
		{
			p[i]->next=p[i]->pre;
			p[i]->pre=0;
			*ptr=p[i];
		}
		else
		{
			p[i]->next=p[i]->pre;
			p[i]->pre=p[i+1];
		}
	}
	p[0]->pre=p[0]->next;
	p[0]->next=*ptr;
}

//////////////////

void rev_data1(ST *ptr)
{
	ST *temp=malloc(sizeof(ST));
	int count=count_node(ptr),i,j;
	ST **p=malloc(sizeof(ST *)*count);
	for(i=0;i<count;i++)
	{
		p[i]=ptr;
		ptr=ptr->next;
	}
	for(i=0,j=count-1;i<j;i++,j--)
	{
		strcpy(temp->name,p[i]->name);
		temp->roll=p[i]->roll;
		temp->marks=p[i]->marks;

		strcpy(p[i]->name,p[j]->name);
		p[i]->roll=p[j]->roll;
		p[i]->marks=p[j]->marks;

		strcpy(p[j]->name,temp->name);
		p[j]->roll=temp->roll;
		p[j]->marks=temp->marks;
	}
}

///////////////////

void rev_data(ST *ptr)
{
	ST *temp,*temp1=ptr;
	char a[20];
	int count=count_node(ptr),i,j,roll1;
	float marks1;
	for(i=0;i<count/2;i++)
	{
		temp=ptr;
		for(j=0;j<count-1-i;j++)
			temp=temp->next;

		strcpy(a,temp1->name);
		roll1=temp1->roll;
		marks1=temp1->marks;

		strcpy(temp1->name,temp->name);
		temp1->roll=temp->roll;
		temp1->marks=temp->marks;

		strcpy(temp->name,a);
		temp->roll=roll1;
		temp->marks=marks1;

		temp1=temp1->next;
	}
}

//////////////////
void rev_print3(ST *ptr)
{
	int count=count_node(ptr),i;
	ST **p=malloc(sizeof(ST *)*count);
	for(i=0;i<count;i++)
	{
		p[i]=ptr;
		ptr=ptr->next;
	}
	for(i=count-1;i>=0;i--)
		printf("%s %d %f\n",p[i]->name,p[i]->roll,p[i]->marks);
}

//////////////////
void rev_print2(ST *ptr)
{
	ST *temp;
	int count=count_node(ptr),i,j;
	for(i=0;i<count;i++)
	{
		temp=ptr;
		for(j=0;j<count-1-i;j++)
			temp=temp->next;
		printf("%s %d %f\n",temp->name,temp->roll,temp->marks);
	}
}

//////////////////
void rev_print1(ST *ptr,ST *ptr1)
{
	if(ptr)
	{
		if(ptr->next!=ptr1)
			rev_print1(ptr->next,ptr1);
		printf("%s %d %f\n",ptr->name,ptr->roll,ptr->marks);
	}
}

//////////////////

int count_node(ST *ptr)
{
	ST *temp=ptr;
	int count=0;
	while(temp)
	{
		count++;
		if(temp->next==ptr)
			break;
		temp=temp->next;
	}
	return count;
}

//////////////////

void print_node(ST *ptr)
{
	ST *temp=ptr;
	while(temp)
	{
		printf("%s  %d  %f\n",temp->name,temp->roll,temp->marks);
		if(temp->next==ptr)
			break;
		temp=temp->next;
	}
}
///////////////////////
void add_begin(ST **ptr)
{
	ST *temp;
	static ST *temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student at begin\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;

	if(*ptr==0)
	{
		*ptr=temp;
		temp->next=*ptr;
		temp1=temp;
	}
	else
	{
		temp->next=*ptr;
		(*ptr)->pre=temp;
		*ptr=temp;
		temp1->next=*ptr;
	}
}

////////////////////

void add_end(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student at end\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;
	if(*ptr==0)
	{
		*ptr=temp;
		temp->next=*ptr;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next!=*ptr)
			temp1=temp1->next;

		temp1->next=temp;
		temp->pre=temp1;
		temp->next=*ptr;
	}
}

////////////////////////////

void add_middle(ST **ptr)
{
	ST *temp,*temp2;
	static ST *temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll ans marks of student at middle\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;
	if(*ptr==0)
	{
		*ptr=temp;
		temp->next=*ptr;
		temp1=temp;
	}
	else if(temp->roll<(*ptr)->roll)
	{
		temp->next=*ptr;
		(*ptr)->pre=temp;
		*ptr=temp;
		temp1->next=*ptr;
	}
	else
	{
		temp2=*ptr;
		while(temp2)
		{
			if(temp2->next==*ptr)
			{
				temp->next=temp2->next;
				temp2->next=temp;
				temp->pre=temp2;
				temp1=temp;
				break;
			}
			if(temp->roll<=temp2->next->roll)
			{
				temp->next=temp2->next;
				temp->pre=temp2;
				temp2->next=temp;
				break;
			}
			temp2=temp2->next;
		}
	}
}//























