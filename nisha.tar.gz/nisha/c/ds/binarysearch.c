// write a program for binary searching in array
#include<stdio.h>
main()
{
	int a[20];
	int n,i,beg,end,mid,item;
	printf("enter the number of element\n");
	scanf("%d",&n);
	printf("enter element\n");
	for(i=0;i<n;i++)
		scanf("%d",a+i);
	printf("enter item\n");
	scanf("%d",&item);
	beg=0;
	end=n-1;
	mid=(beg+end)/2;
	while(beg<=end&&a[mid]!=item)
	{
		if(a[mid]<item)
			beg=mid+1;
		else
			end=mid-1;
		mid=(beg+end)/2;
	}
	if(a[mid]==item)
		printf("%d is founded at %d position\n",item,mid);
	else
		printf("item does not exit\n");
}
