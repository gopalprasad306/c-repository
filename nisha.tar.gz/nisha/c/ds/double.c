#include"header1.h"
void add_begin(ST **);  // add nodes at begin
void add_middle(ST **); // add nodes at middle
void add_end(ST **);    // add nodes at end
void print_node(ST *);  // printing node
void rev_link(ST **);   // reverse link using nesting for loop
void rev_link1(ST **);  // reverse link using double pointer
int  node_count(ST *);   // count node
void rev_data(ST *);     // rev data using for loop
void rev_data1(ST *);    //rev data using double pointer
void del_dupnode(ST *);  // to delete duplicate node 
main()
{
	ST *headptr=0;
	char ch;
	do
	{
//		add_begin(&headptr);
//		add_middle(&headptr);
		add_end(&headptr);
		printf("do u want to add more link list\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');
//	rev_link(&headptr);
//	rev_link1(&headptr);
//	rev_data(headptr);
//	rev_data1(headptr);
	del_dupnode(headptr);
	print_node(headptr);

}//

///////////////

void print_node(ST *ptr)
{
	while(ptr)
	{
		printf("%s  %d  %f\n",ptr->name,ptr->roll,ptr->marks);
		ptr=ptr->next;
	}
}

//////////////

void del_dupnode(ST *ptr)
{
	ST *temp,*temp1;
	while(ptr)
	{
		temp=ptr->next;
		while(temp)
		{
			temp1=temp;
			if(temp->roll==ptr->roll)
			{
				if(temp->next!=0)
				{
					temp->next->pre=temp->pre;
					temp->pre->next=temp->next;
					free(temp);
				}
				else
				{
					temp->pre->next=temp->next;
					free(temp);
				}
			}
			temp=temp1->next;
		}
		ptr=ptr->next;
	}
}

/////////////
void add_begin(ST **ptr)
{
	ST *temp;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks at begin\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;
	if(*ptr==0)
	{
		*ptr=temp;
	}
	else
	{
		(*ptr)->pre=temp;
		temp->next=*ptr;
		*ptr=temp;
	}
}

//////////////

void add_end(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks at end\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;
	if(*ptr==0)
	{
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp1->next=temp;
		temp->pre=temp1;
	}
}

///////////////
void add_middle(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student to add in middle\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	temp->pre=temp->next=0;
	if(*ptr==0)
	{
		*ptr=temp;
	}
	else if(temp->roll<(*ptr)->roll)
	{
		temp->next=*ptr;
		(*ptr)->pre=temp;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1->next==0)
			{
				temp1->next=temp;
				temp->pre=temp1;
				break;
			}
			if(temp->roll<=temp1->next->roll)
			{
				temp->next=temp1->next;
				temp1->next->pre=temp;
				temp->pre=temp1;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}
	}


}//

///////////////

int node_count(ST *ptr)
{
	int count=0;
	while(ptr)
	{
		count++;
		ptr=ptr->next;
	}
	return count;
}

////////////////

void rev_link(ST **ptr)
{
	ST *temp,*temp1,*temp2;
	int i,j,node;
	node=node_count(*ptr);
	for(i=0;i<=node-1;i++)
	{
		temp=*ptr;
		for(j=0;j<node-1-i;j++)
		{
			temp=temp->next;
			if(j==node-2)
				temp2=temp;
		}
		temp1=temp->next;
		temp->next=temp->pre;
		temp->pre=temp1;
	}
	*ptr=temp2;
}

////////////////

void rev_link1(ST **ptr)
{
	ST *temp=*ptr,*temp1;
	int node,i;
	node=node_count(*ptr);
	ST **p=malloc(sizeof(ST *)*node);
	for(i=0;i<node;i++)
	{
//		p[i]=malloc(sizeof(ST));
		p[i]=temp;
		temp=temp->next;
	}
	for(i=0;i<node;i++)
	{
		temp1=p[i]->next;
		p[i]->next=p[i]->pre;
		p[i]->pre=temp1;
	}
	*ptr=p[i-1];
}//

//////////////////

void rev_data(ST *ptr)
{
	ST *temp=ptr,*temp1,*T;
	T=malloc(sizeof(ST));
	int node,i,j;
	node=node_count(ptr);
	for(i=0;i<node/2;i++)
	{
		temp1=ptr;
		for(j=0;j<node-1-i;j++)
			temp1=temp1->next;

		strcpy(T->name,temp->name);
		T->roll=temp->roll;
		T->marks=temp->marks;
		strcpy(temp->name,temp1->name);
		temp->roll=temp1->roll;
		temp->marks=temp1->marks;
		strcpy(temp1->name,T->name);
		temp1->roll=T->roll;
		temp1->marks=T->marks;

		temp=temp->next;
	}

}//

///////////////

void rev_data1(ST *ptr)
{
	int node,i,j;
	ST **p,*temp=ptr;
	node=node_count(ptr);
	p=malloc(sizeof(ST *)*node);
	for(i=0;i<node;i++)
	{
		p[i]=temp;
		temp=temp->next;
	}
	temp=malloc(sizeof(ST));
	for(i=0,j=node-1;i<j;i++,j--)
	{
		strcpy(temp->name,p[i]->name);
		temp->roll=p[i]->roll;
		temp->marks=p[i]->marks;
		strcpy(p[i]->name,p[j]->name);
		p[i]->roll=p[j]->roll;
		p[i]->marks=p[j]->marks;
		strcpy(p[j]->name,temp->name);
		p[j]->roll=temp->roll;
		p[j]->marks=temp->marks;

	}
}






















