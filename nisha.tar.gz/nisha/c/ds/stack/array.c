#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct student
{
	int TOP;
	int capacity;
	int *r;
};
typedef struct student ST;


ST * stack(int num)
{
	ST *p=malloc(sizeof(ST));
	p->TOP=-1;
	p->capacity=num;
	p->r=malloc(sizeof(int)*num);
	return(p);
}//

int isfull(ST *p)
{
	if(p->TOP==p->capacity-1)
		return(1);
	else 
		return(0);
}//

push(ST *p,int num)
{
	if(isfull(p))
	{
		printf("stack overflow \n");
		return;
	}
	else
	{
		p->TOP++;
		p->r[p->TOP]=num;
	}
}//

int is_empty(ST *p)
{
	if(p->TOP==-1)
		return(1);
	else
		return 0;
}

int pop(ST *p)
{
	int num;
	if(is_empty(p))
	{
		printf("stack underflow\n");
		return 0;
	}
	else
	{
		num=p->r[p->TOP];
		p->TOP--;
	}
	return num;
}

main()
{
	int choice,num,num1;
	ST *p;
	p=stack(5);
		printf("1) push\n2) pop\n3) exit\n4)clear screen\n");
	while(1)
	{
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				printf("enter number which u want to insert in stack\n");
				scanf("%d",&num);
				push(p,num);
				break;
			case 2:
				num1=pop(p);
				if(num1!=0)
				printf("%d\n",num1);
				break;
			case 3:
				exit(0);
			case 4:
				system("clear");
				printf("1) push\n2) pop\n3) exit\n4)clear screen\n");
				break;
			default:
				printf("wrong choice\n");
				break;
		}//switch
		//getchar();
	}
}//










