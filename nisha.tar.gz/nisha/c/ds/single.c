#include"header.h"
void add_begin(ST **);
void add_middle(ST **);
void add_end(ST **);
void print_node(ST *);
void rev_link(ST **);         // reverse the link using array of pointer
void rev_link1(ST **,ST **);  // reverse the link using recursion
void rev_link2(ST **);        //reverse link using 2 for loop
void rev_data(ST *);          // reverse data using 2 for loop
void rev_data1(ST *);         //reverse data using array of pointer
void rev_data2(ST *);          //reverse data using recursion
void del_node(ST **);
int  count_node(ST *);
void del_duplicate_node(ST *);
main()
{
	ST *headptr=0;
	char ch;
	do
	{
//		add_begin(&headptr);
//		add_middle(&headptr);
		add_end(&headptr);
		printf("do u want to add more nodes(y/n)\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');
//	rev_link(&headptr);
//	rev_link1(&headptr,&headptr);
//	rev_link2(&headptr);
//	rev_data1(headptr);

//	rev_data(headptr);
//	del_node(&headptr);
//	del_duplicate_node(headptr);
	print_node(headptr);
}//main ends

////////////////////////

void rev_data1(ST *ptr)
{
int node,i,j;
ST v;
node=count_node(ptr);
ST **p=malloc(sizeof(ST *)*node);
for(i=0;i<node;i++)
{
p[i]=ptr;
ptr=ptr->next;
}
for(i=0,j=node-1;i<j;i++,j--)
{
strcpy(v.name,p[i]->name);
v.roll=p[i]->roll;
v.marks=p[i]->marks;
strcpy(p[i]->name,p[j]->name);
p[i]->roll=p[j]->roll;
p[j]->marks=p[j]->marks;
strcpy(p[j]->name,v.name);
p[j]->roll=v.roll;
p[j]->marks=v.marks;
}

}

//////////////////////

void rev_link2(ST **ptr)
{
	ST *temp,*temp1,*temp2;
	int node=count_node(*ptr);
	int i,j;
	for(i=0;i<=node;i++)
	{
		temp=*ptr;
		for(j=0;j<node-1-i;j++)
		{
			temp1=temp;
			temp=temp->next;
			if(temp->next==0)
				temp2=temp;
		}
		temp->next=temp1;
	}
	temp->next=0;
	*ptr=temp2;
}

///////////////////////

void rev_link1(ST **ptr,ST **p)
{
	ST *temp,*temp1;
	static ST *temp3;
	temp=*ptr;
	if(temp->next)
	{
		rev_link1(&temp->next,p);
		temp1=temp->next;
		temp1->next=temp;
		if(temp==temp3)
			temp->next=0;
	}
	else
	{
		temp3=*p;
		*p=temp;
	}
}//

///////////////////////

void print_node(ST *ptr)
{
	while(ptr)
	{
		printf("%s  %d  %f\n",ptr->name,ptr->roll,ptr->marks);
		ptr=ptr->next;
	}
}

//////////////////////////

void add_begin(ST **ptr)
{
	ST *temp;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student to add in begin\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);

	temp->next=*ptr;
	*ptr=temp;
	/*
if(*ptr==0)
{
*ptr=temp;
temp->next=0;
}
else
{
temp->next=*ptr;
*ptr=temp;
}
*/
}

/////////////////////////

void add_end(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student at end\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	if(*ptr==0)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1->next)
			temp1=temp1->next;

		temp->next=temp1->next;
		temp1->next=temp;
	}
}

/////////////////////////

void add_middle(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks of student to add in middle\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	if(*ptr==0||temp->roll<(*ptr)->roll)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1->next==0||temp->roll<temp1->next->roll)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}
	}
}//

////////////////////////////

int count_node(ST *ptr)
{
	int count=0;
	while(ptr)
	{
		count++;
		ptr=ptr->next;
	}
	return count;
}

////////////////////////////

void rev_link(ST **ptr)
{
	ST *temp=*ptr;
	int node=count_node(*ptr),i;
	ST **p=malloc(sizeof(ST *)*node);
	for(i=0;i<node;i++)
	{
		p[i]=malloc(sizeof(ST));
		p[i]=temp;
		temp=temp->next;
	}
	(*ptr)->next=0;
	for(i=1;i<node;i++)
		p[i]->next=p[i-1];
	*ptr=p[i-1];
}//

////////////////////////////

void rev_data(ST *ptr)
{
	ST *temp=ptr,*temp1;
	ST *temporary=malloc(sizeof(ST));
	int i,node,j,k;
	node=count_node(ptr);
	for(i=0;i<node/2;i++)
	{
		temp1=ptr;
		for(k=0;k<node-1-i;k++)
			temp1=temp1->next;

		strcpy(temporary->name,temp->name);
		temporary->roll=temp->roll;
		temporary->marks=temp->marks;
		strcpy(temp->name,temp1->name);
		temp->roll=temp1->roll;
		temp->marks=temp1->marks;
		strcpy(temp1->name,temporary->name);
		temp1->roll=temporary->roll;
		temp1->marks=temporary->marks;

		temp=temp->next;
	}
}//

///////////////////////////////

void del_node(ST **ptr)
{
	ST *temp=*ptr,*temp1;
	int roll;
	printf("enter rollnumber which you want to delete in list\n");
	scanf("%d",&roll);
	while(temp)
	{
		if(temp->roll==roll)
		{
			if(roll==(*ptr)->roll)
			{
				*ptr=temp->next;
				free(temp);
				break;
			}
			else
			{
				temp1->next=temp->next;
				free(temp);
				break;
			}
		}
		temp1=temp;
		temp=temp->next;
	}
}

////////////////////

void del_duplicate_node(ST *ptr)
{
	ST *temp,*temp1,*temp2;
	while(ptr)
	{

		temp=ptr->next;
		while(temp)
		{
			if(ptr->roll==temp->roll)
			{
				if(ptr->next==temp)
				{
					ptr->next=temp->next;
					free(temp);
				}
				else
				{
					temp1->next=temp->next;
					free(temp);
				}
			}
			temp1=temp;
			temp=temp->next;
		}
		ptr=ptr->next;
	}//
}
//















































