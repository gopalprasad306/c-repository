#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct student
{
char name[20];
int roll;
float marks;
struct student *next;
};
typedef struct student ST;

