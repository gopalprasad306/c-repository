// write a program to sort  a array using insertion short
#include<stdio.h>
main()
{
int a[20];
int n,i,j,temp;
printf("enter number of element\n");
scanf("%d",&n);
printf("enter number\n");
for(i=0;i<n;i++)
scanf("%d",a+i);

for(i=1;i<n;i++)
{
temp=a[i];
for(j=i-1;j>=0&&temp<a[j];j--)
a[j+1]=a[j];

a[j+1]=temp;
}
printf("after sorting\n");
for(i=0;i<n;i++)
printf("%d ",a[i]);
printf("\n");
}//
