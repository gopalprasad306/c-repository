/* write a program to swap k th node from begning and k th node from end in a single link list.
ex A - B -C -D -E -F -G -H -I  If k =2 then 
 
   A - H -C -D- E -F -G -B -I
*/
#include<stdio.h>
#include<stdlib.h>

struct student
{
	char name[20];
	int roll;
	float marks;
	struct student *next;
};
typedef struct student ST;
void add_middle(ST **);
void print_node(ST *);
void swp(ST **,int);  //assignment 4
int count_node(ST *); 
void swp_adjacent(ST **); //assignment 5
void del_node(ST **);    //delete a partciler node from last 
main()
{
	ST *headptr=0;
	int k;
	char ch;
	do
	{
		add_middle(&headptr);
		printf("do u want add more nodes\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');
//	printf("enter k th position for swapping in linklist\n");
//	scanf("%d",&k);
//	swp(&headptr,k);
//	swp_adjacent(&headptr);
	del_node(&headptr);
	print_node(headptr);
}

//////////////////

void del_node(ST **ptr)
{
ST *temp,*temp1,*temp2,*temp3=*ptr;
int num,i;
printf("enter which node u want to delete from last\n");
scanf("%d",&num);

while(temp3)
{
temp1=temp3;
temp2=temp1;
for(i=0;i<num;i++)
temp1=temp1->next;
if(!temp1)
{
if(temp2==*ptr)
{
*ptr=temp2->next;
free(temp2);
break;
}
else
{
temp->next=temp2->next;
free(temp2);
break;
}
}
temp=temp3;
temp3=temp3->next;
}
}

//////////////////

void swp_adjacent(ST **ptr)
{
	ST *temp,*temp1,*temp2;
	temp=*ptr;
	temp1=temp->next;
	int node=count_node(*ptr),i;
	for(i=0;i<node/2;i++)
	{
		if(i==0)
		{
			temp->next=temp1->next;
			temp1->next=temp;
			*ptr=temp1;
		}
		else
		{
			temp2=temp;
			temp=temp->next;
			temp1=temp->next;

			temp->next=temp1->next;
			temp1->next=temp;
			temp2->next=temp1;
		}
		//temp2=temp;
		//temp=temp->next; // here temp contain 0
		//temp1=temp->next; //here in temp1 contain garbage means 0->next  that why segmentaion fault comes
	}

}

//////////////////

void swp(ST **ptr,int k)
{
	ST *temp,*temp1,*temp2,*temp3,*temp4;
	temp1=*ptr;
	temp3=*ptr;
	int node=count_node(*ptr),i,j;
	if(k==1||k==node)
	{
		if(k==node)
			k=1;
		for(i=0;i<node-k;i++)
		{
			temp2=temp3;
			temp3=temp3->next;
		}
		temp4=temp1->next;
		temp2->next=temp1;
		temp1->next=temp3->next;
		temp3->next=temp4;
		*ptr=temp3;
	}
	else
	{
		for(i=1;i<k;i++)
		{
			temp=temp1;
			temp1=temp1->next;
		}
		for(j=0;j<node-k;j++)
		{
			temp2=temp3;
			temp3=temp3->next;
		}
		temp4=temp1->next;
		temp2->next=temp1;
		temp1->next=temp3->next;
		temp->next=temp3;
		temp3->next=temp4;
	}
}

/////////////////

int count_node(ST *ptr)
{
int count=0;
while(ptr)
{
count++;
ptr=ptr->next;
}
return count;
}

/////////////////

void print_node(ST *ptr)
{
	while(ptr)
	{
		printf("%s %d %f\n",ptr->name,ptr->roll,ptr->marks);
		ptr=ptr->next;
	}
}

////////////////////

void add_middle(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter name roll and marks at middle\n");
	scanf("%s%d%f",temp->name,&temp->roll,&temp->marks);
	if(*ptr==0||temp->roll<(*ptr)->roll)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1->next==0||temp->roll>=temp1->roll&&temp->roll<temp1->next->roll)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}
	}
}//











