#include<stdio.h>
#include<stdlib.h>
struct student
{
	int roll;
	struct student *next;
};
typedef struct student ST;

void add_middle(ST **);
void merge_link_list(ST *,ST *,ST **);
void print_node(ST *);
int node_count(ST *);
void add(ST *,ST *,ST **);
main()
{
	ST *headptr=0;
	ST *headptr1=0;
	ST *headptr2=0;
	char ch;
	do
	{
		add_middle(&headptr);
		printf("do u want to add more node in first link_list\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');

	do
	{
		add_middle(&headptr1);
		printf("do u want to add more mode in 2nd link_list\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');

//	merge_link_list(headptr,headptr1,&headptr2);
	add(headptr,headptr1,&headptr2);
	print_node(headptr2);
}//main

///////////////

void print_node(ST *ptr)
{
	while(ptr)
	{
		printf("%d\n",ptr->roll);
		ptr=ptr->next;
	}
}
////////////////////

int node_count(ST *ptr)
{
	int count=0;
	while(ptr)
	{
		count++;
		ptr=ptr->next;
	}
	return count;
}

///////////////////
void add_middle(ST **ptr)
{
	ST *temp,*temp1;
	temp=malloc(sizeof(ST));
	printf("enter rollnumber\n");
	scanf("%d",&temp->roll);
	if(*ptr==0||temp->roll<(*ptr)->roll)
	{
		temp->next=*ptr;
		*ptr=temp;
	}
	else
	{
		temp1=*ptr;
		while(temp1)
		{
			if(temp1->next==0||temp->roll<temp1->next->roll)
			{
				temp->next=temp1->next;
				temp1->next=temp;
				break;
			}
			temp1=temp1->next;
		}
	}
}

//////////////////

void merge_link_list(ST *ptr,ST *ptr1,ST **ptr2)
{
	int node,node1,i;
	node=node_count(ptr);
	node1=node_count(ptr1);
	for(i=0;i<node||i<node1;i++)
	{
		ST *temp,*temp1,*temp2;
		temp=malloc(sizeof(ST));
		temp2=malloc(sizeof(ST));
		if(i<node)
		{
			if(*ptr2==0)
			{
				temp->roll=ptr->roll;
				temp->next=*ptr2;
				*ptr2=temp;
				ptr=ptr->next;
			}
			else
			{
				temp->roll=ptr->roll;
				temp1=*ptr2;
				while(temp1->next)
					temp1=temp1->next;

				temp->next=temp1->next;
				temp1->next=temp;
				ptr=ptr->next;
			}
		}
		if(i<node1)
		{
			if(*ptr2==0)
			{
				temp2->roll=ptr1->roll;
				temp2->next=*ptr2;
				*ptr2=temp2;
				ptr1=ptr1->next;
			}
			else
			{
				temp2->roll=ptr1->roll;
				temp1=*ptr2;
				while(temp1->next)
					temp1=temp1->next;

				temp2->next=temp1->next;
				temp1->next=temp2;
				ptr1=ptr1->next;
			}
		}

	}//for
}//fun  close

//////////////////////////

void add(ST *ptr,ST *ptr1,ST **ptr2)
{
	int node,node1,num,num1,i;
	node=node_count(ptr);
	node1=node_count(ptr1);
	for(i=0;i<node||i<node1;i++)
	{
		ST *temp=malloc(sizeof(ST)),*temp1;
		num=0,num1=0;
		if(ptr)
		{
			num=ptr->roll;
			ptr=ptr->next;
		}
		if(ptr1)
		{
			num1=ptr1->roll;
			ptr1=ptr1->next;
		}
		temp->roll=num+num1;
		if(*ptr2==0)
		{
			temp->next=*ptr2;
			*ptr2=temp;
		}
		else
		{
			temp1=*ptr2;
			while(temp1->next)
				temp1=temp1->next;

			temp->next=temp1->next;
			temp1->next=temp;
		}
	}//for
}//function close























