// write a program to delete a particular node a/c to any signature of structure

