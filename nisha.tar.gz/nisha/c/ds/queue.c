//  implementation of queue
#include<stdio.h>
#include<stdlib.h>
struct student
{
	int front;
	int rear;
	int capacity;
	int *p;
};
typedef struct student ST;

ST * create_queue(int);
int is_empty(ST *);
int is_full(ST *);
void enque(ST *,int);
int deque(ST *);

main()
{
	ST *q;
	int capacity;
	printf("enter length of queue\n");
	scanf("%d",&capacity);
	q=create_queue(capacity);
	enque(q,3);
	enque(q,6);
	printf("%d\n",deque(q));
	printf("%d\n",deque(q));
}

/////////////////

int deque(ST *q)
{
	int num;
	if(is_empty(q))
	{
		printf("queue is empty\n");
		return;
	}
	else
	{
		num=q->p[q->front];
		if(q->front==q->rear)
			q->front=q->rear=-1;
		else
			q->front=(q->front+1)%q->capacity;
		return num;
	}
}
////////////////
void enque(ST *q,int num)
{
	if(is_full(q))
	{
		printf("queue is full\n");
		return;
	}
	else
	{
		q->rear=(q->rear+1)%q->capacity;
		q->p[q->rear]=num;
		if(q->front==-1)
			q->front=q->rear;
	}
}

////////////////

ST * create_queue(int capacity)
{
	ST *q=malloc(sizeof(ST));
	q->front=q->rear=-1;
	q->capacity=capacity;
	q->p=malloc(sizeof(int)*q->capacity);
	return q;
}

///////////////////

int is_empty(ST *q)
{
	return(q->front==-1);
}

//////////////////

int is_full(ST *q)
{
	return((q->rear+1)%q->capacity==q->front);
}

//////////////////

















