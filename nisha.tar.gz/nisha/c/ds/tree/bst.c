#include<stdio.h>
#include<stdlib.h>

struct student
{
	struct student *left;
	int roll;
	struct student *right;
};
typedef struct student ST;

void insert_node(ST **,int);
void print_NLR(ST *);
main()
{
	ST *root=0;
	char ch;
	int rollno;
	do
	{
		printf("enter rollnumber\n");
		scanf("%d",&rollno);
		insert_node(&root,rollno);
		printf("do u want to add more node\n");
		scanf(" %c",&ch);
	}while(ch=='y'||ch=='Y');
	print_NLR(root);
}
///////////////

void print_NLR(ST *ptr)
{
	if(ptr)
	{
		printf("%d\n",ptr->roll);
		print_NLR(ptr->left);
		print_NLR(ptr->right);
	}
}

///////////////////

void insert_node(ST **ptr,int rollno)
{
	if(!(*ptr))
	{
		ST *temp;
		temp=malloc(sizeof(ST));
		temp->left=temp->right=0;
		temp->roll=rollno;
		*ptr=temp;
	}
	if(rollno<(*ptr)->roll)
		insert_node(&(*ptr)->left,rollno);
	if(rollno>(*ptr)->roll)
		insert_node(&(*ptr)->right,rollno);
}//













