// 9) Write a Program to reverse the Contents of a given file
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int l,i;
	FILE *fp;
	char *p,*q,temp;
	fp=fopen("richa","r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,SEEK_END);
	l=ftell(fp);
	rewind(fp);
	p=(char *)malloc(l+1);
	q=(char *)malloc(l+1);
	while(fgets(q,l,fp)!=NULL)
		strcat(p,q);
	for(l=0;p[l];l++);
	for(i=0,l=l-2;i<l;i++,l--)
	{
		temp=p[i];
		p[i]=p[l];
		p[l]=temp;
	}
	fclose(fp);
	printf("%s",p);
	fp=fopen("richa","w");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fputs(p,fp);
	fclose(fp);
}//
