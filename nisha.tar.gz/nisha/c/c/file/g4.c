// 4) Write a Program to Capitalize First Letter of every Word in a file.
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
	int l,count;
	FILE *fp;
	char *p,*q;
	fp=fopen("nisha","r+");
	if(fp==0)
	{
		perror("open");
		return 0;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	p=(char *)malloc(l+1);
	q=(char *)malloc(l+1);
	rewind(fp);
	while(fgets(q,l,fp)!=NULL)
	{
		int i;
		for(i=0;q[i];i++)
		{
			count=0;
			if(i==0)
				q[i]=q[i]-32;
			else if(q[i]==' ')
			{
				while(q[i]==' ')
					i++;
				q[i]=q[i]-32;
			}
		}
		strcat(p,q);
	}
	printf("%s",p);
	fclose(fp);
	fp=fopen("nisha","w");
	fputs(p,fp);
	fclose(fp);
}




