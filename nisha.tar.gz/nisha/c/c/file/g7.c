// 7) Write a Program to copy the one file into multiple destination files which are provided during the loadtime.
#include<stdio.h>
int main(int argc,char **argv)
{
	int i;
	if(argc<3)
	{
		printf("usage:plz give correct input\n");
		return;
	}
	FILE *fp,*fp1;
	char a[20];
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	for(i=2;i<argc;i++)
	{
		rewind(fp);
		fp1=fopen(argv[i],"w");
		if(fp1==0)
		{
			perror("open");
			return;
		}
		while(fgets(a,20,fp)!=NULL)
			fputs(a,fp1);
		fclose(fp1);
	}
	fclose(fp);
}//
