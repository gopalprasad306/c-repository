// 2) Write a Program to remove a Specific line from the given text file.
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
	FILE *fp;
	int line,l,count=0;
	char *p,*q;
	printf("enter which line u want to delete\n");
	scanf("%d",&line);
	fp=fopen("megha","r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	rewind(fp);
	p=(char *)malloc(l+1);
	q=(char *)malloc(l+1);
	while(fgets(q,l,fp)!=NULL)
	{
		count++;
		if(count!=line)
			strcat(p,q);
	}
	fclose(fp);
	fp=fopen("megha","w");
	fputs(p,fp);
	fclose(fp);
}
