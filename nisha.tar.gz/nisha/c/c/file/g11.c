/* 11) Write a Program to implement grep command. 
            ( Check the command:  grep  searching_word  filename.c )
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main(int argc,char **argv)
{
	char a[50],*p;
	FILE *fp;
	if(argc!=3)
	{
		printf("usage:plz give correct input\n");
		return;
	}
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	while(fgets(a,50,fp)!=NULL)
	{
		if(p=strstr(a,argv[2]))
			printf("%s",p);
	}
	fclose(fp);
}
