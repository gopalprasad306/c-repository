/*   12) Write a Program to implement wc command.
             (Check the command: wc filename.c)
*/
#include<stdio.h>
main(int argc,char **argv)
{
	int count=0,count1=0,l;
	char a[200];
	if(argc!=2)
	{
		printf("usage:plz give correct input\n");
		return;
	}
	FILE *fp;
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	rewind(fp);
	while(fgets(a,100,fp)!=NULL)
	{
		count++;
	}
	rewind(fp);
	while(fscanf(fp,"%s ",a)!=EOF)
	{
		count1++;
	}
	printf("%d %d %d %s\n",count,count1,l,argv[1]);
	fclose(fp);
}//
