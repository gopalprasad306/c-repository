// 6) Write a Program to replace the word with the reverse of that word in a given file.
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
	int l;
	char *p,*a;
	FILE *fp;
	fp=fopen("nisha","r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	rewind(fp);
	p=(char *)malloc(l+1);
	a=(char *)malloc(l+1);
	while(fgets(a,l,fp))
	{
		int j,i=0,k;
		char temp;
		for(j=0;a[j]||a[j]=='\0';j++)
		{
			if(a[j]==' '||a[j]=='\0')
			{
				if(a[j]=='\0')
					k=j-2;
				else
					k=j-1;
				for(i;i<k;i++,k--)
				{
					temp=a[i];
					a[i]=a[k];
					a[k]=temp;
				}
				i=j+1;
			}
			if(a[j]=='\0')
				break;
		}
		strcat(p,a);
	}
	printf("%s",p);
}//main





