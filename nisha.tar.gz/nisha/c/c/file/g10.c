/* 10) Write a Program to implement sort command.
             (Check the command:  sort  filename.c )
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main(int argc,char **argv)
{
	int l,count=0,i,j;
	char *p,**q,*temp;
	if(argc!=2)
	{
		printf("usage:plz give correct input\n");
		return;
	}
	FILE *fp;
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	rewind(fp);
	p=(char *)malloc(l+1);
	while(fgets(p,l,fp))
	{
		count++;
	}
	rewind(fp);
	q=(char **)malloc(sizeof(char *)*count);
	for(i=0;i<count;i++)
	{
		fgets(p,l,fp);
		j=strlen(p);
		q[i]=(char *)malloc(j+1);
		strcpy(q[i],p);
	}
	for(i=0;i<count-1;i++)
	{
		for(j=0;j<count-1-i;j++)
			if(strcmp(q[j],q[j+1])>0)
			{
				temp=q[j];
				q[j]=q[j+1];
				q[j+1]=temp;
			}
	}
	fclose(fp);
	fp=fopen(argv[1],"w");
	for(i=0;i<count;i++)
		fputs(q[i],fp);
	fclose(fp);
}















