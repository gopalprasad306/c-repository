//  5) Write a Program to merges the lines from two files and store the result into another file.
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main(int argc,char **argv)
{
	char a[50],count=0,count1=0,i,l,l1;
	FILE *fp,*fp1,*fp2;
	char *p;
	if(argc!=4)
	{
		printf("usage: give correct input\n");
		return;
	}
	fp=fopen(argv[1],"r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fp1=fopen(argv[2],"r");
	if(fp1==0)
	{
		perror("open");
		return;
	}
	fp2=fopen(argv[3],"w");
	if(fp1==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	fseek(fp1,0,2);
	l1=ftell(fp1);
	rewind(fp);
	rewind(fp1);
	while(fgets(a,50,fp))
		count++;
	while(fgets(a,50,fp1))
		count1++;
	rewind(fp);
	rewind(fp1);
	p=(char*)malloc(l+l1+1);
	for(i=0;i<count||i<count1;i++)
	{
		if(fgets(a,50,fp))
			strcat(p,a);
		if(fgets(a,50,fp1))
			strcat(p,a);
	}
	fputs(p,fp2);
	fcloseall();
}//main























