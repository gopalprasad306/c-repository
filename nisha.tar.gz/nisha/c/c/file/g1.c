// 1) Write a Program to Convert Lower to Upper and Upper to Lower Cases of a given file.
#include<stdio.h>
main()
{
	FILE *fp;
	char ch;
	fp=fopen("nisha","r+");
	if(fp==0)
	{
		perror("open");
		return;
	}
	while((ch=fgetc(fp))!=EOF)
	{
		fseek(fp,-1,1);
		if(ch>='a'&&ch<='z')
			ch=ch-32;
		else if(ch>='A'&&ch<='Z')
			ch=ch+32;
		fputc(ch,fp);
	}
	fclose(fp);
}
