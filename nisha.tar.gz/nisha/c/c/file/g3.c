// 3) Write a Program to replace a Specified line in a given file.
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main()
{
	int l,line,count=0;
	FILE *fp;
	char a[20],*p,*q;
	printf("enter line\n");
	scanf("%d",&line);
	printf("string which will replace by a specified line\n");
	scanf("%s",a);
	fp=fopen("megha","r");
	if(fp==0)
	{
		perror("open");
		return;
	}
	fseek(fp,0,2);
	l=ftell(fp);
	p=(char *)malloc(l+1);
	q=(char *)malloc(l+1);
	rewind(fp);
	while(fgets(q,l,fp)!=NULL)
	{
		count++;
		if(count==line)
		{
			strcat(p,a);
			strcat(p,"\n");
		}
		else
			strcat(p,q);
	}
	fclose(fp);
	fp=fopen("megha","w");
	fputs(p,fp);
	fclose(fp);
}



