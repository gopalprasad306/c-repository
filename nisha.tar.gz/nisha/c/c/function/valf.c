// demo program of variable argumnet list function
#include<stdio.h>
#include<stdarg.h>
int sum(char *,...);
main()
{
	int num,num1,num2,res;
	printf("enter value for num,num1,num2\n");
	scanf("%d%d%d",&num,&num1,&num2);
	res=sum("hello",num,num1,0);
	printf("%d\n",res);
	res=sum("hai",num,num1,num2,0);
	printf("%d\n",res);
}

int sum(char *p,...)
{
	int i,sum=0,r;
	va_list v;
	va_start(v,p);
	while(1)
	{
		r=va_arg(v,int);
		if(r==0)
			break;
		else
			sum=sum+r;
	}
	return sum;
}

/*
main()
{
	int num,num1,num2,res;
	printf("enter value for num,num1 and num2\n");
	scanf("%d%d%d",&num,&num1,&num2);
	res=sum(2,num,num1);
	printf("%d\n",res);
	res=sum(3,num,num1,num2);
	printf("%d\n",res);
}
int sum(int n,...)
{
	int i,sum=0;
	va_list v;
	va_start(v,n);
	for(i=0;i<n;i++)
		sum=sum+va_arg(v,int);
	return sum;
}
*/
