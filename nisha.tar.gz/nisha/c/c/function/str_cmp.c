//  str_cmp function
#include<stdio.h>
int str_cmp(const char *,const char *);
main()
{
	int num;
	char a[20],b[20];
	printf("enter first string\n");
	scanf("%s",a);
	printf("enter second string\n");
	scanf("%s",b);
	num=str_cmp(a,b);
	if(num==0)
		printf("both string are equal\n");
	else if(num>0)
		printf("first string is greater than second\n");
	else
		printf("first string is smaller than second\n");
}
int str_cmp(const char *a,const char *b)
{
	int i;
	for(i=0;a[i];i++)
		if(a[i]!=b[i])
			break;
	if(a[i]==b[i])
		return 0;
	else if(a[i]>b[i])
		return 1;
	else if(a[i]<b[i])
		return -1;

}
