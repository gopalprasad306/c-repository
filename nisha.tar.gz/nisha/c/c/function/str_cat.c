// str_cat function
#include<stdio.h>
char * str_cat(char *,const char *);
main()
{
	char a[30],b[10],*p;
	printf("enter  a string\n");
	scanf("%s",a);
	printf("enter second string\n");
	scanf("%s",b);
	p=str_cat(a,b);
	printf("%s\n",p);
}
char * str_cat(char *a,const char *b)
{
	int i,j;
	for(i=0;a[i];i++);
	for(j=0;b[j];j++)
		a[i++]=b[j];
	a[i]=b[j];
	return a;
}
