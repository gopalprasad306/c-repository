//  str_n_cmp function
#include<stdio.h>
int str_n_cmp(const char *,const char *,int);
main()
{
	int n,num; 
	char a[20],b[20];
	printf("enter first string\n");
	scanf("%s",a);
	printf("enter second string\n");
	scanf("%s",b);
	printf("enter number\n");
	scanf("%d",&n);
	num=str_n_cmp(a,b,n);
	if(num==0)
		printf("string are equal till %d element\n",n);
	else if(num>0)
		printf("first string is bigger than second string till %d element\n",n);
	else
		printf("first string is smaller than second string till %d element\n",n);
}//
int str_n_cmp(const char *a,const char *b,int n)
{
	int i;
	for(i=0;a[i] && i<n-1;i++)
		if(a[i]!=b[i])
			break;
	if(a[i]==b[i])
		return 0;
	else if(a[i]>b[i])
		return 1;
	else
		return -1;
}//
