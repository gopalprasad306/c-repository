//str_rev function
#include<stdio.h>
main()
{
	int i,j;
	char a[20],temp;
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i];i++);
	for(j=i-1,i=0;i<j;i++,j--)
	{
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	printf("%s\n",a);
}
