#include<stdio.h>
float a_tof(char *p);
main()
{
float f;
char a[10];
printf("enter a string in float notation\n");
scanf("%s",a);
f=a_tof(a);
printf("%f\n",f);
}

float a_tof(char *p)
{
int i,num=0,num1=0;
float f,div=1;
for(i=0;p[i]!='.';i++)
num=num*10+p[i]-48;
for(i=i+1;p[i];i++)
{
num1=num1*10+p[i]-48;
div=div*10.0;
}
f=num+(float)num1/div;
return(f);
}
