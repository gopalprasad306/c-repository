// str_chr function
#include<stdio.h>
#define _GNU_SOURCE  
char * str_chr(const char *,char);
main()
{
	char a[20],ch,*p;
	printf("enter a string\n");
	scanf("%s",a);
	printf("enter a charcter\n");
	scanf(" %c",&ch);
	p=str_chr(a,ch);
	if(p==0)
		printf("%c is not present \n",ch);
	else
		printf("%s\n",p);
}//
char * str_chr(const char *a,char ch)
{
	int i;
	for(i=0;a[i]!='\0'&&a[i]!=ch;i++);
	if(!a[i])
		return NULL;
	else
		return a+i;
}
