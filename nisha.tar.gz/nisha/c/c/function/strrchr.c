// str_r_r_chr function
#include<stdio.h>
char * str_r_r_chr(char *a,char ch);
main()
{
	char a[20],ch,*p;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	printf("enter a charcter\n");
	scanf(" %c",&ch);
	p=str_r_r_chr(a,ch);
	if(p==0)
		printf("%c is not present\n",ch);
	else
		printf("%s\n",p);
}
char * str_r_r_chr(char *a,char ch)
{
	int i;char *p;
	for(i=0;a[i];i++);
	for(--i;a[i]!=ch && i>=0;i--);
	return i<0 ?0:a+i; 
}
