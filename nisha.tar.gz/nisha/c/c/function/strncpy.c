// str_n_cpy function
#include<stdio.h>
char * str_n_cpy(char *,const char *,int);
main()
{
	int i,n;
	char a[20],b[20],*p;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	printf("enter n\n");
	scanf("%d",&n);
	p=str_n_cpy(b,a,n);
	printf("copied string is %s\n",p);
}
char * str_n_cpy(char *b,const char *a,int n)
{
	int i;
	for(i=0;a[i]!='\0' && i!=n;i++)
	{
		b[i]=a[i];
	}
	b[i]='\0';
	return b;
}
