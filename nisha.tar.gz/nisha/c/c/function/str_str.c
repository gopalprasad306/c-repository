//  str_str.c
#include<stdio.h>
char * str_str(const char *,const char *);
main()
{
	char a[20],b[10],*p;
	printf("enter main string\n");
	scanf("%s",a);
	printf("enter substring \n");
	scanf("%s",b);
	p=str_str(a,b);
	p?printf("%s\n",p):printf("substring is not present\n");
}

char * str_str(const char *a,const char *b)
{
	int i,j;
	for(i=0;a[i];i++)
	{
		for(j=0;b[j];j++)
			if(a[i+j]!=b[j])
				break;
		if(b[j]=='\0')
			return a+i;
	}
	return 0;
}


/*
   char * str_str(const char *a,const char *b)
   {
   int i,j;
   for(i=0;a[i];i++)
   {
   if(a[i]==b[0])
   {
   for(j=1;b[j];j++)
   if(b[j]!=a[i+j])
   break;
   if(b[j]=='\0')
   return a+i;
   }
   }
   return 0;
   }//
 */
