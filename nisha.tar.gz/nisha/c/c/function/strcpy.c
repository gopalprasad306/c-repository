#include<stdio.h>
main()
{
int i;
char a[20],b[20];
printf("enter a string\n");
scanf("%[^\n]",a);
for(i=0;a[i];b[i]=a[i],i++);
b[i]=a[i];
printf("b=%s\n",b);
}
