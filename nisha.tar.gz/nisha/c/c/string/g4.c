// 4) Write a program to find vowels in a given  string.
#include<stdio.h>
main()
{
int i;
char a[20];
printf("enter a string\n");
scanf("%s",a);
for(i=0;a[i];i++)
{
if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')
printf("%c ",a[i]);
}
printf("\n");
}
