/* 12) Write a program to print the count of duplicate characters in a given string.
       Ex:  Input : “hrithik roshan”
              Output:  Letter  -------  Count
                               h-------      3
		               r-------      2
                               i-------      2
*/
#include<stdio.h>
main()
{
	int i,count=0,j,k;
	char a[20];
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(i=0;a[i];i++)
	{
		count=0;
		for(j=i+1;a[j];j++)
			if(a[i]==a[j])
			{
				for(k=j;a[k];k++)
					a[k]=a[k+1];
				count++;
				j--;
			}
		if(count>0)
			printf("%c-----%d\n",a[i],count+1);
	}
}
