// 3) Write a program to find the no.of times the character is found in a given string.
#include<stdio.h>
main()
{
	int count=0,i;
	char a[20],ch;
	printf("enter a string\n");
	scanf("%s",a);
	printf("enter a charcter\n");
	scanf(" %c",&ch);
	for(i=0;a[i];i++)
		if(a[i]==ch)
			count++;
	if(count>0)
		printf("%c is %d times present in string\n",ch,count);
	else
		printf("%c is not present\n",ch);
}
