/* 7)  Write a program to check the given strings are palindrom or not.
     Note: Palindrome words are words which read and spell the same way both backwards  
               and  forwards. Some examples,  
               madam, level , radar, stats and etc. 
*/
#include<stdio.h>
#include<string.h>
main()
{
	int i,j;
	char a[20],b[20],temp;
	printf("enter a string to chek palidrome\n");
	scanf("%s",a);
	strcpy(b,a);
	for(i=0;a[i];i++);
	for(j=i-1,i=0;i<j;i++,j--)
	{
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	if(strcmp(a,b)==0)
		printf("yes palindrome\n");
	else
		printf("no palindrome\n");
}
