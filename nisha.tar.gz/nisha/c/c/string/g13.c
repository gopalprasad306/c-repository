/* 13) Write a program to find count of  Lower characters, Upper characters, Special characters
      and digits occured in a given string.
*/
#include<stdio.h>
#include<string.h>
main()
{
	int i,count=0,count1=0,count2=0,count3=0,len;
	char a[20];
	printf("enter a string\n");
	scanf("%[^\n]",a);
	len=strlen(a);
	for(i=0;a[i];i++)
	{
		if(a[i]>='a'&&a[i]<='z')
			count++;
		else if(a[i]>='A'&&a[i]<='Z')
			count1++;
		else if(a[i]>='0'&&a[i]<='9')
			count2++;
		else if(a[i]==' ')
			count3++;
	}
	printf("lower char=%d\nupper char=%d\ndigits=%d\nspecial char=%d\n",count,count1,count2,len-(count+count1+count2+count3));
}
