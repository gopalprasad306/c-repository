// 6) Write a program to reverse the string using loops & recursion.
#include<stdio.h>
void rev_string(char *,int,int);
main()
{
	int i,j;
	char a[20],temp;
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i];i++);
/*
	for(j=i-1,i=0;i<j;i++,j--)
	{
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
*/
	rev_string(a,0,i-1);
	printf("%s\n",a);

}
void rev_string(char *a,int i,int j)
{
char temp;
if(i<j)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
rev_string(a,i+1,j-1);
}
}
