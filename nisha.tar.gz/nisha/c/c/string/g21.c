/* 21) Write a program to read two strings through the keyboard like the following example 
       and replace any word of  the second string with the first string.
      Ex: Input:-           Fist String      : “Tomorrow”
                            Second String    : “Today is Sunday”
                            Replace word     : “Today”.

            Output:-  “Tomorrow is Sunday”          
*/
#include<stdio.h>
#include<string.h>
char *str_str(char *,char *);
main()
{
	int d,l,i;
	char a[10],b[30],c[10],*p;
	printf("enter the string that would be replaced\n");
	scanf("%s",a);
	printf("enter main string\n");
	scanf(" %[^\n]",b);
	printf("enter replace word\n");
	scanf(" %s",c);
	p=str_str(b,c);
	if(p==0)
		printf("repalce word is not present\n");
	else
	{
		d=strlen(a)-strlen(c);
		if(d>0)
		{
			l=strlen(b);
			for(l;b+l!=p+(strlen(c)-1);l--)
				b[l+d]=b[l];
			for(i=0;a[i];i++)
				p[i]=a[i];
		}
		else
		{
			d=-d;
			for(i=strlen(c);p[i];i++)
				p[i-d]=p[i];
			p[i-d]='\0';
			for(i=0;a[i];i++)
				p[i]=a[i];
		}
	}
	printf("%s\n",b);
}//main

char * str_str(char *a,char *b)
{
	int i,j;
	for(i=0;a[i];i++)
	{
		for(j=0;b[j];j++)
			if(a[i+j]!=b[j])
				break;
		if(b[j]=='\0')
			return a+i;
	}
	return 0;
}

