// write a program to enter a password and match
#include<stdio.h>
main()
{
int i=0;
char a[5],ch;
printf("enter a password\n");
for(i=0;i<5;i++)
{
scanf("%c",a+i);
printf("*");
}
}
