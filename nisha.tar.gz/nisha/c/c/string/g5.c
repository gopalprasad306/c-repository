// 5) Write a program to compare two strings without using strcmp function.
#include<stdio.h>
int str_cmp(const char *,const char *);
main()
{
	int res,i;
	char a[20],b[20];
	printf("enter two string\n");
	scanf("%s%s",a,b);
	res=str_cmp(a,b);
	if(res==0)
		printf("both string are equal\n");
	else if(res>0)
		printf("first string is greater than second\n");
	else
		printf("first string is smaller than second string\n");

}
int str_cmp(const char *a,const char *b)
{
	int i;
	for(i=0;a[i];i++)
		if(a[i]!=b[i])
			break;
	if(a[i]==b[i])
		return 0;
	else if(a[i]>b[i])
		return 1;
	else
		return -1;
}

