/* 19) Write a program to replace the words in reverse order in a given string line.
	Ex:  Input   :  “world changed your thoughts”
	       Output :  “thoughts your changed world”
*/
#include<stdio.h>
#include<string.h>
main()
{
	int i,len,j=0;
	char a[40],temp;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	len=strlen(a)-1;
	for(i=0;i<len;i++,len--)
	{
		temp=a[i];
		a[i]=a[len];
		a[len]=temp;
	}
	for(i=0;a[i]||a[i]=='\0';i++)
	{
		if(a[i]==' '||a[i]=='\0')
		{
			len=i-1;
			for(j;j<len;j++,len--)
			{
				temp=a[j];
				a[j]=a[len];
				a[len]=temp;
			}
			j=i+1;
			if(a[i]=='\0')
				break;
		}
	}
	printf("%s\n",a);
}
