/* 18) Write a program to reverse the words in a given string line.
       Ex : “I am a good boy”
	  “I ma a doog yob”
*/
#include<stdio.h>
main()
{
	int i,l,temp,j=0;
	char a[20];
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(i=0;a[i]||a[i]=='\0';i++)
	{
		if(a[i]==' '||a[i]=='\0')
		{
			l=i-1;
			for(j;j<l;j++,l--)
			{
				temp=a[j];
				a[j]=a[l];
				a[l]=temp;
			}
			j=i+1;
			if(a[i]=='\0')
				break;
		}
	}
	printf("%s\n",a);
}
