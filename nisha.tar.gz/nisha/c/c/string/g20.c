/* 20)Write a program to declare an array of string pointers. Use function “input” to input the strings 
      from stdin into array of string pointers, sort them in assending order according to string length.
      Note: Use DMA
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main()
{
	char **p,*temp;
	int n,i,j;
	printf("enter how many string u want \n");
	scanf("%d",&n);
	p=malloc(sizeof(char *)*n);
	printf("enter %d string\n",n);
	for(i=0;i<n;i++)
	{
		p[i]=malloc(sizeof(20));
		scanf(" %[^\n]",p[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
			if(strlen(p[j])>strlen(p[j+1]))
			{
				temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
	}
	for(i=0;i<n;i++)
		printf("%s\n",p[i]);
}
