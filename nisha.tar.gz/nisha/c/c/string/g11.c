/* 11) Write a program to delete the duplicate characters in a given string.
      Ex: Input : vecteeovvorr
             Output : vector
*/
#include<stdio.h>
main()
{
	int i,j,k;
	char a[20];
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i];i++)
	{
		for(j=i+1;a[j];j++)
			if(a[i]==a[j])
			{
				for(k=j;a[k];k++)
					a[k]=a[k+1];
				j--;
			}
	}
	printf("%s\n",a);
}
