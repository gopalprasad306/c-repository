/* 14) Write a program to convert the characters Upper to Lower and Lower to Upper in a
      given string.
*/
#include<stdio.h>
main()
{
	int i;
	char a[20];
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i];i++)
	{
		if(a[i]>='a'&&a[i]<='z')
			a[i]=a[i]-32;
		else if(a[i]>='A'&&a[i]<='Z')
			a[i]=a[i]+32;
	}
	printf("%s\n",a);
}
