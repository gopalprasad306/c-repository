/*      22) Write a program to check given strings are anagram or not.
      Note : Both strings are anagram, if  both contains same elements, same no.of times in any order.
                 (Can have extra special characters & digits also)

      Ex:   "Osama bin laden"  ,  "Old man in a base"  both are anagrams.
	  “study”  , “dus%@ty123” both are anagrams. 
			      Here after removing special characters and digits ----> “ dusty “.
*/
#include<stdio.h>
main()
{
	unsigned int sum=0,sum1=0;
	int i,j;
	char a[20],b[20];
	printf("enter first string\n");
	scanf("%[^\n]",a);
	printf("enter second string\n");
	scanf(" %[^\n]",b);
	for(i=0;a[i];i++)
		if(a[i]>='a'&&a[i]<='z')
			sum=sum+a[i];

	for(j=0;b[j];j++)
		if(b[j]>='a'&&b[j]<='z')
			sum1=sum1+b[j];
	if(sum==sum1)
		printf("anagram\n");
	else
		printf("not anagram\n");
}
