/* 16) Write a program to accept two strings from user into two character array and copy one 
       by one character into another destination array.
	Ex:  First String      : “abcdefg”
                   Second String : “1234”
	        then  Destination String  is  “a1b2c3d4efg”
*/
#include<stdio.h>
#include<string.h>
main()
{
	int i,j,len1,len2,k=0;
	char a[20],b[20],c[40];
	printf("enter two string\n");
	scanf("%s%s",a,b);
	len1=strlen(a);
	len2=strlen(b);
	for(i=0,j=0;i<len1||j<len2;i++,j++)
	{
		if(i<len1)
			c[k++]=a[i];
		if(j<len2)
			c[k++]=b[j];
	}
	printf("%s\n",c);
}
