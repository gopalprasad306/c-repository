// wap to find the longest palindrome in a string
#include<stdio.h>
#include<string.h>
void palindrome(char *,int,int);
main()
{
	int l;
	char a[20];
	printf("enter  a string\n");
	scanf("%s",a);
	l=strlen(a);
	palindrome(a,0,l-1);
}
void palindrome(char *a,int m,int n)
{
	char p[20],temp;
	strcpy(p,a);
	int i=m,j=n;
	for(i;i<j;i++,j--)
	{
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	if(strcmp(p,a)==0)
		printf("%s\n",a);
	else
	{
		a[n]='\0';
		a=a+1;
		palindrome(a,m,n-2);
	}
}
