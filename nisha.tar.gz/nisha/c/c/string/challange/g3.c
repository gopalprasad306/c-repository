// wap to swap adjecent char in a string
#include<stdio.h>
main()
{
	int i;
	char a[20],temp;
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i]&&a[i+1];i+=2)
	{
		temp=a[i];
		a[i]=a[i+1];
		a[i+1]=temp;
	}
	printf("%s\n",a);
}
