// wap to cahnge a char in upper to lower and viceversa  and reverse the integer
#include<stdio.h>
main()
{
	int i,j,k;
	char a[20],temp;
	printf("enter a string\n");
	scanf("%s",a);
	for(i=0;a[i];i++)
	{
		if(a[i]>='a'&&a[i]<='z')
			a[i]=a[i]-32;
		else if(a[i]>='A'&&a[i]<='Z')
			a[i]=a[i]+32;
		if(a[i]>='0'&&a[i]<='9')
		{
			j=i;
			for(k=i;a[k]>='0'&&a[k]<='9';k++);
			i=k-1;
			for(j,k=k-1;j<k;j++,k--)
			{
				temp=a[j];
				a[j]=a[k];
				a[k]=temp;
			}
		}
	}
	printf("%s\n",a);
}
