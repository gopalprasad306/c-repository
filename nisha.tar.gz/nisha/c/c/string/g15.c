// 15) Write a program to sort a given string in ascending order.
#include<stdio.h>
#include<string.h>
main()
{
	int i,len,j,op;
	char a[20],temp;
	printf("enter a string\n");
	scanf("%s",a);
	len=strlen(a);
	printf("1) bubble sort\n2) selection sort\n");
	scanf("%d",&op);
	switch(op)
	{
		case 1:
			for(i=0;i<len-1;i++) //  bubble sort
			{
				for(j=0;j<len-1-i;j++)
					if(a[j]>a[j+1])
					{
						temp=a[j];
						a[j]=a[j+1];
						a[j+1]=temp;
					}
			}
			break;
		case 2:
			for(i=0;i<len-1;i++)
			{
				for(j=i+1;j<len;j++)
					if(a[i]>a[j])
					{
						temp=a[i];
						a[i]=a[j];
						a[j]=temp;
					}
			}
			break;
		default:
			printf("wrong option\n");
			break;
	}
	printf("%s\n",a);
}




