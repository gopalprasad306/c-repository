// 17) Write a program to find the no.of times substring is found in a given string.
#include<stdio.h>
main()
{
	int i,j,count=0;
	char a[20],b[20];
	printf("enter a string\n");
	scanf("%s",a);
	printf("enter a  substring\n");
	scanf("%s",b);
	j=0;
	for(i=0;a[i];i++)
	{
		if(a[i]==b[0])
		{
			for(j=1;b[j];j++)
				if(a[i+j]!=b[j])
					break;
			if(b[j]=='\0')
				count++;
		}
	}
	printf("number of substring=%d\n",count);
}
