/* 10) Write a program to remove the conjucutive spaces in a given string line.
       Ex: Input:  Vector        India      Pvt     Ltd
             Output: Vector India Pvt Ltd;
*/
#include<stdio.h>
main()
{
	int i,j;
	char a[30];
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(i=0;a[i];i++)
	{
		if(a[i]==' '&&a[i+1]==' ')
		{
			for(j=i;a[j];j++)
				a[j]=a[j+1];
			i--;
		}
	}
	printf("%s\n",a);
}
