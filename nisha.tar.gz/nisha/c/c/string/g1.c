// 1) Write a program to find  string length using pointer.
#include<stdio.h>
int str_len(char *);
main()
{
	char a[20],len;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	len=str_len(a);
	printf("%d\n",len);
}
int str_len(char *p)
{
	int i;
	for(i=0;p[i];i++);
	return i;
}
