/* 8) Write a program to find the no.of words are presented in a given string line.
     Note: User has to input the string line at runtime.
*/
#include<stdio.h>
main()
{
	int i,count=0;
	char a[20];
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(i=0;a[i];i++)
		if(a[i]==' ')
			count++;
	printf("%d word are in string\n",count+1);
}
