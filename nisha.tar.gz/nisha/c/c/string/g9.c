/* 9) Write a program to delete a desired character in a given string.
     Ex:  Input : embedded
            character: 'd'
             Output : embee
*/
#include<stdio.h>
main()
{
	int i,j;
	char a[20],ch;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	printf("entet a chracter which u want to delete from string\n");
	scanf(" %c",&ch);
	for(i=0;a[i];i++)
	{
		if(a[i]==ch)
		{
			for(j=i;a[j];j++)
				a[j]=a[j+1];
			i--;
		}
	}
	printf("%s\n",a);
}
