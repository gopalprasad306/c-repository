/* 12. Write a program to swap the adjucent bytes of  a given 4-digit hexadecimal
      number.
      Ex : given number  = 0x1234;
	      after swap :      0x3412;
*/
#include<stdio.h>
main()
{
int num,i,j;
printf("enter a number\n");
scanf("%x",&num);
printf("%x\n",num);
for(i=0,j=8;i<8;i++,j++)
if((num>>i&1)!=(num>>j&1))
{
num=num^(1<<i);
num=num^(1<<j);
}
printf("%x\n",num);
}
