// 3.  WAP to find the given number is +ve or -ve using bitwise operators.
#include<stdio.h>
main()
{
int num;
printf("enter a number\n");
scanf("%d",&num);
if(num>>(sizeof(int)*8-1)&1)
printf("number is - negative\n");
else
printf("number is positive\n");
}
