// 2. WAP to find the given number is even or odd using bitwise operators.
#include<stdio.h>
main()
{
int num;
printf("enter a number\n");
scanf("%d",&num);
if(num>>0&1)
printf("number is odd\n");
else
printf("number is even\n");
}
