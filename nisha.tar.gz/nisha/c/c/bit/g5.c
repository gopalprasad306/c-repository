// 5. WAP to find the given number is power of 2 or not.
#include<stdio.h>
main()
{
int num,count=0,i;
printf("enter a number\n");
scanf("%d",&num);
for(i=31;i>=0;i--)
{
if(num>>i&1)
count++;
}
if(count==1)
printf("power of two\n");
else
printf("not power of two\n");
}
