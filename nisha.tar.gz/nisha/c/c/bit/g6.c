// WAP to find the given number is divisble by 8 or not using bitwise operators.
#include<stdio.h>
main()
{
int num;
printf("enter a number\n");
scanf("%d",&num);
if( !(num>>2&1) && !(num>>1&1) && !(num>>0&1))
printf("divible of 8\n");
else
printf("not divisible of 8\n");
}
