/* 1.  Write a prorgram for the following one.
      a) Set a bit      b) Clear a bit    c) Toggle a  bit  
*/
#include<stdio.h>
main()
{
	int i,bit,num,op;
	printf("enter  a number \n");
	scanf("%d",&num);
	printf("enter a bit position\n");
	scanf("%d",&bit);
	for(i=31;i>=0;printf("%d",num>>i&1),i--);
	printf("\n");
	printf("1) set a bit\n2) clear a bit\n3) toggle a bit\n");
	scanf("%d",&op);
	printf("\n");
	switch(op)
	{
		case 1:
			num=num|(1<<bit);
			break;

		case 2:
			num=num&~(1<<bit);
			break;

		case 3:
			num=num^(1<<bit);
			break;

		default:
			printf("invalid option\n");
			break;
	}
	for(i=31;i>=0;printf("%d",num>>i&1),i--);
	printf("\n");
}
