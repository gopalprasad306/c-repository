// 4.  WAP to swap two numbers using bitwise operators.
#include<stdio.h>
main()
{
int num1,num2;
printf("enter two number\n");
scanf("%d%d",&num1,&num2);
printf("before\nnum1=%d num2=%d\n",num1,num2);
num1=num1^num2;
num2=num1^num2;
num1=num1^num2;
printf("after\nnum1=%d num2=%d\n",num1,num2);
}
