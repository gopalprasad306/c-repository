/* 8. Convert the characters Upper to Lower and Lower to Upper using bitwise
    operators.
*/
#include<stdio.h>
main()
{
char ch;
printf("enter a character\n");
scanf("%c",&ch);
printf("before \n%c   \n",ch);
ch=ch^(1<<5);
printf("after\n%c    \n",ch);
}
