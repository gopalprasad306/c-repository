/* 7. Write a program to rotate the bits. Input  the no.of  rotations, at runtime.
    Ex : binary  :  10000000000000000000000000001011
            rotations : suppose 3 times right,  then
    	result    :  01110000000000000000000000000001

           binary  :  10000000000000000000000000001011
           rotations : suppose 4 times left,  then
	result :   00000000000000000000000010111000
*/
#include<stdio.h>
main()
{
	int num,bit,op,x,y,z,i;
	printf("enter a number\n");
	scanf("%d",&num);
	printf("1) right shift\n2)left shift\n");
	scanf("%d",&op);
	printf("before\n");
	for(i=31;i>=0;printf("%d",num>>i&1),i--);
	printf("\n");
	switch(op)
	{
		case 1:
			printf("enter by how many bit u want to shift right\n");
			scanf("%d",&bit);
			x=num>>bit;
			y=num<<(32-bit);
			num=x|y;
			break;
		case 2:
			printf("enter by how many bit u want to shift left\n");
			scanf("%d",&bit);
			x=num<<bit;
			y=num>>(32-bit);
			num=x|y;
			break;
		default:
			printf("wrong option\n");
			break;
	}
	printf("after\n");
	for(i=31;i>=0;printf("%d",num>>i&1),i--);
	printf("\n");
}






