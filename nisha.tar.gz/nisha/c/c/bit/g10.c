// 10. Write a one line code to compare two numbers using bitwise operators.
#include<stdio.h>
main()
{
int num1,num2,i,c;
printf("enter two number\n");
scanf("%d%d",&num1,&num2);
c=num1-num2;
if(c|0)
printf("not equal\n");
else
printf("equal\n");


/*
for(i=0;i<31;i++)
if((num1>>i&1)!=(num2>>i&1))
break;
if(i==31)
printf("number equal\n");
else
printf("not equal\n");
*/
}
