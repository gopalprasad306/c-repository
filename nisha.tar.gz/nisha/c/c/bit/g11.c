// 11. Write a program to print float binay formation using char *ptr.
#include<stdio.h>
main()
{
int i,j;
float f;
char *p;
printf("enter a float number\n");
scanf("%f",&f);
p=&f;
p=p+3;
for(i=3;i>=0;i--)
{
for(j=7;j>=0;j--)
printf("%d",*p>>j&1);
p--;
}
printf("\n");
}
