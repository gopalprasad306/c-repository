/*
              *
             ***
            *****
           *******
          *********
         ***********
          *********
           *******
            *****
             ***
              *
*/
#include<stdio.h>
main()
{
	int n,n1,i,j,k;
	printf("enter number\n");
	scanf("%d",&n);
	k=n+1;
	for(i=-n;i<=n;i++)
	{
		n1=i;
		if(n1<0)
			n1=-n1;
		for(j=0;j<n1;j++)
			printf(" ");
		if(i<=0)
		{
			for(j=0;j<k-n1;j++)
				printf("*");
			printf("\n");
			k++;
		}
		else
		{
			if(i==1)
				k=k-2;
			for(j=0;j<k-n1;j++)
				printf("*");
			printf("\n");
			k--;
		}
	}
}//main








