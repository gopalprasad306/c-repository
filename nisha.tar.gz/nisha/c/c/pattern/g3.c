/*
         * * * * * *
          * * * * *
           * * * *
            * * *
             * *
              *
             * *
            * * *
           * * * *
          * * * * *
         * * * * * *
*/
#include<stdio.h>
main()
{
	int n,i,j,k;
	printf("enter a number\n");
	scanf("%d",&n);
	for(i=-n;i<=n;i++)
	{
		if(i<0)
			k=-i;
		else
			k=i;
		for(j=0;j<n-k;j++)
			printf(" ");
		for(j=0;j<k+1;j++)
			printf("* ");
		printf("\n");
	}
}//
