/*

                     *
	            * *
                   * * *
                  * * * *
                 * * * * *
                  * * * *
                   * * *
                    * *
                     *
*/
#include<stdio.h>
main()
{
	int n,i,j,n1;
	printf("enter a number\n");
	scanf("%d",&n);
	for(i=-n;i<=n;i++)
	{
		n1=i;
		if(n1<0)
			n1=-n1;
		for(j=0;j<n1;j++)
			printf(" ");
		for(j=0;j<n+1-n1;j++)
			printf("* ");
		printf("\n");
	}
}//main
