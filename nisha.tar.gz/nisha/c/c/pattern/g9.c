/*
9)	           1 
	         1 2 3 
	       1 2 3 4 5 
 	     1 2 3 4 5 6 7 
           1 2 3 4 5 6 7 8 9 
*/
#include<stdio.h>
main()
{
int i,j,num,num1;
printf("enter a number\n");
scanf("%d",&num);
for(i=0;i<num;i++)
{
num1=1;
for(j=0;j<num-1-i;j++)
printf("  ");
for(j=0;j<2*i+1;j++)
printf("%d ",num1++);
printf("\n");
}
}//main
