/*
   14) -6-5-4-3-2-1 0 1 2 3 4 5 6
0       A B C D E F G F E D C B A 
1	A B C D E F   F E D C B A 
2	A B C D E       E D C B A 
3	A B C D           D C B A 
4	A B C               C B A 
5	A B                   B A 
6	A                       A 
*/

#include<stdio.h>
main()
{
	char ch;
	int i,j,num;
	printf("enter number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		ch='A';
		for(j=-(num-1);j<num;j++)
		{
			if(j==0)
			{
				if(i==0)
					printf("%c ",ch);
				else
					printf("  ");
				ch--;
			}
			else if(-i>=j||i<=j)
			{
				if(j<0)
					printf("%c ",ch++);
				else
				{
					printf("%c ",ch--);
				}
			}
			else
			{
				printf("  ");
			}
		}
		printf("\n");
	}
}//main

