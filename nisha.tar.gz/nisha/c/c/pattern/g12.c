/*
12)
	1                 1 
	1 2             2 1 
	1 2 3         3 2 1 
	1 2 3 4     4 3 2 1 
	1 2 3 4 5 5 4 3 2 1 
*/
#include<stdio.h>
main()
{
	int i,j,num,k,l;
	printf("enter number\n");
	scanf("%d",&num);
	for(i=num;i>0;i--)
	{
		l=1;
		for(j=-num;j<=num;j++)
		{
			if(j==0)
				l--;

			else if(-i>=j||i<=j)
			{
				if(j<0)
					printf("%d ",l++);
				else
					printf("%d ",l--);
			}
			else
			{
				printf("  ");
			}
		}
		printf("\n");
	}
}//main
