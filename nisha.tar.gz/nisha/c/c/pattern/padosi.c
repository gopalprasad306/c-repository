/*
1
2*3
4*5*6
4*5*6
2*3
1
*/
#include<stdio.h>
main()
{
	int i,j,num,k,num1,l=1,num2;
	printf("enter number\n");
	scanf("%d",&num);
	num1=num;
	for(i=-num;i<=num;i++)
	{
		k=i;
		if(i<0)
			k=-i;
		if(i<0)
		{
			++num1;
			num2=l;
			for(j=0;j<(num1-k);j++)
			{
				if(j%2==0)
					printf("%d ",l++);
				else
					printf("* ");
			}
			l=num2*2;
		}
		else if(i>0)
		{
			if(i==1)
				l=l/2;
			num2=l;
			for(j=0;j<num1-k;j++)
			{
				if(j%2==0)
					printf("%d ",l++);
				else
					printf("* ");
			}
			num1--;
			l=num2/2;
		}
		if(i!=0)
		printf("\n");
	}
}









