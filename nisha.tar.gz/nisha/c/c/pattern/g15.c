/*
                
         	  1 
	         1 1 
	        1 2 1 
	       1 3 3 1 
	      1 4 6 4 1 
	     1 5 10 10 5 1 
*/
#include<stdio.h>
main()
{
int i,j,num;
printf("enter number\n");
scanf("%d",&num);
for(i=0;i<num;i++)
{
for(j=0;j<i+1;j++)

}
}//main













