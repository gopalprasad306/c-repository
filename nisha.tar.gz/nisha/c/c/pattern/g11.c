/*
11)
	1 
	2 4 
	3 6 9 
	4 8 12 16 
	5 10 15 20 25 
	6 12 18 24 30 36 
*/
#include<stdio.h>
main()
{
	int i,j,num,num1=1,num2=2,k,l;
	printf("enter number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		k=1;
		l=1;
		if(i%2==0)
		{
			for(j=0;j<i+1;j++)
				printf("%d ",num1*(k++));
			num1=num1+2;
		}
		else
		{
			for(j=0;j<i+1;j++)
				printf("%d ",num2*(l++));
			num2=num2+2;
		}
		printf("\n");
	}
}//main
