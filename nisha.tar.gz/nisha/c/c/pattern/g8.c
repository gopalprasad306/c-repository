/*
8)	1 
	2 6 
	3 7 10 
	4 8 11 13 
	5 9 12 14 15 
*/
#include<stdio.h>
main()
{
	int i,j,num,num1=0,num2,k;
	printf("enter number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		num1++;
		num2=num1;
		for(j=0;j<i+1;j++)
		{
			if(j==0)
			{
				printf("%d ",num2);
				k=4;
			}
			else
			{
				num2=num2+k;
				printf("%d ",num2);
				k--;
			}
		}
		printf("\n");
	}
}//main
