/*
1               1
1 2           2 1
1 2 3       3 2 1
1 2 3 4   4 3 2 1
1 2 3 4 5 4 3 2 1
*/
#include<stdio.h>
main()
{
	int i,j,num,l;
	printf("enter numbar\n");
	scanf("%d",&num);
	printf("\n\n");
	for(i=num;i>0;i--)
	{
		l=1;
			for(j=-(num-1);j<num;j++)
			{
				if(j==0)
				{
					if(i==1)
					{
						printf("%d ",l);
					}
					else
					{
						printf("  ");
					}
					l--;
				}
				else if(-i>=j-1||i<=j+1)
				{
					if(j<0)
					{
						printf("%d ",l++);
					}
					else
					{
						printf("%d ",l--);
					}
				}
				else
				{
					printf("  ");
				}
			}
		printf("\n");
	}
}//main
















