/*
                   1
                 1 2 3 
               1 2 3 4 5
             1 2 3 4 5 6 7  
           1 2 3 4 5 6 7 8 9
             1 2 3 4 5 6 7 
               1 2 3 4 5 
                 1 2 3
                   1
*/
#include<stdio.h>
main()
{
	int i,j,num,k,num1,num2;
	printf("enter number\n");
	scanf("%d",&num);
	num2=num;
	for(i=-num;i<=num;i++)
	{
		num1=1;
		k=i;
		if(i<0)
			k=-i;
		for(j=0;j<k;j++)
			printf("  ");
		if(i<=0)
		{
			++num2;
			for(j=0;j<(num2-k);j++)
				printf("%d ",num1++);
		}
		else
		{
			--num2;
			for(j=0;j<(num2-k);j++)
				printf("%d ",num1++);
		}
		printf("\n");
	}
}//main












