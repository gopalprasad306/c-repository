// write a program chek a lowercase using macro
#include<stdio.h>
#define LOWERCASE(ch) ch>='a'&&ch<='z'
int main()
{
char ch;
printf("enter a char\n");
scanf("%c",&ch);
if(LOWERCASE(ch))
printf("yes it is a lower case\n");
else
printf("not a lower case\n");
}
