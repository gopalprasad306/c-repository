// write a program to show whether a char is alphanumric or not using nesting of macro
#include<stdio.h>
#define ISLOWERCASE(ch) (ch>='a'&&ch<='z')
#define ISUPPERCASE(ch) (ch>='A'&&ch<='Z')
#define ISNUMERIC(ch) (ch>='0'&&ch<='9')
#define ISALPHANUMRIC ISLOWERCASE||ISUPPERCASE||ISNUMERIC
int main()
{
char ch;
printf("enter a character\n");
scanf("")
}
