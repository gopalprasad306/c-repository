/*
20)  Write a C program to find the given number is Perfect number or not?
       Note : Perfect number  means sum of it's divisers exept that num is equalent to the same  
                  number.

        Ex :  i/p num = 6.
                6 diviesers  are  =  1,2,3, & 6.
                sum = 1+2+3
                sum  = 6.    So here  6 is perfect number.	
*/
#include<stdio.h>
main()
{
	int num,i,sum=0;
	printf("enter number\n");
	scanf("%d",&num);
	for(i=1;i<num;i++)
		if(num%i==0)
			sum=sum+i;
	if(num==sum)
		printf("%d is a perfect number\n",num);
	else
		printf("%d is not a perfect number\n",num);
}
