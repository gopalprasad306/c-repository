/* 4)   Write a C program to  convert a character. If it is  Lower, convert it to Upper. and if it is
       Upper  convert  it to Lower character.                                                                   complete
*/
#include<stdio.h>
main()
{
	int i;
	char a[20];
	printf("enter a string \n");
	scanf("%[^\n]",a);
	for(i=0;a[i];i++)
	{
		if(a[i]>='a'&&a[i]<='z')
			a[i]=a[i]-32;
		else if(a[i]>='A'&&a[i]<='Z')
			a[i]=a[i]+32;
	}
	printf("%s\n",a);
}
