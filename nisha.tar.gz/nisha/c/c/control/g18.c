/* 18)  Write a C program to find out the biggest number of  three variables using if-else ladder
        and terinary operator.
*/
#include<stdio.h>
main()
{
	int num1,num2,num3;
	printf("enter three number\n");
	scanf("%d%d%d",&num1,&num2,&num3);

printf("biggest number is %d\n",num1>num2 ? num1>num3?num1:num3 : num2>num3?num2:num3);
/*
	if(num1>num2)
	{
		if(num1>num3)
			printf("%d is greater\n",num1);
		else
			printf("%d is greater\n",num3);
	}
	else
	{
		if(num2>num3)
			printf("%d is greater\n",num2);
		else
			printf("%d is greater\n",num3);
	}
*/
}
