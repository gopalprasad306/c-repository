// 13)  Write a C program to find out power of given number without using pow() function.
#include<stdio.h>
main()
{
	int num,n,i,num1;
	printf("enter number\n");
	scanf("%d",&num);
	printf("enter number of power\n");
	scanf("%d",&n);
	num1=num;
	for(i=1;i<n;i++)
		num=num*num1;
	printf("%d\n",num);
}//
