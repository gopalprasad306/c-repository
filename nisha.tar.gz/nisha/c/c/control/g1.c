/* 1)   Write a C Program to Find the factorial of a given number. User has to take the i/p at
       runtime.
*/
#include<stdio.h>
unsigned long int factorial(int);
main()
{
	int num;
	unsigned long int num1;
	printf("enter a number\n");
	scanf("%d",&num);
	num1=factorial(num);
	printf("%lu\n",num1);
}

unsigned long int factorial(int num)
{
	int mul=1,i;
	for(i=num;i>0;i--)
		mul=i*mul;
	return mul;
}
