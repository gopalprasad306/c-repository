// 6)   Write a C program to print first 100 prime numbers.                                                 complete
#include<stdio.h>
main()
{
int num,i,count=0;
for(num=1;count!=100;num++)
{
for(i=2;i<num;i++)
if(num%2==0)
break;
if(num==i)
{
printf("%d ",num);
count++;
}
}
printf("\n");
}//
