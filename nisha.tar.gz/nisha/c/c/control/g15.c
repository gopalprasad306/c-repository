/* 15)  Write a C program to print palindrome numbers between 1 to 1000.
       (palindrome numbers means the numbers which are equal to its reverse.                                    
         Ex : 11,22,33,44,.........999. )
*/
#include<stdio.h>
main()
{
	int num,num1,sum;
	for(num=11;num<1000;num++)
	{
		sum=0;
		num1=num;
		for(num1;num1;sum=sum*10+num1%10,num1/=10);
		if(sum==num)
			printf("%d ",num);
	}
	printf("\n");
}
