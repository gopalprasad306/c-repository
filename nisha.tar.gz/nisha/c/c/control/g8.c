// 8)   Write a C program to print  the binary of a given number( +ve or -ve numbers).
#include<stdio.h>
main()
{
	int num,i;
	printf("enter a number\n");
	scanf("%d",&num);
	for(i=31;i>=0;printf("%d",num>>i&1),i--);
	printf("\n");
}
