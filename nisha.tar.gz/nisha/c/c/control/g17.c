// 17)  Write a C program to find the given number is power of 2 or not.               complete  genric 
#include<stdio.h>
main()
{
	int num,n,i,num1;
	printf("enter a number\n");
	scanf("%d",&num);
	printf("enter a number to chek power\n");
	scanf("%d",&n);
	num1=num;
	for(num;num;num/=n)
	{
		if(num%n>=1)
		{
			printf("%d is not a power of %d\n",num1,n);
			break;
		}
		if(num%n==0&&num/n==1)
		{
			printf("%d is power of %d\n",num1,n);
			break;
		}
	}
}//
