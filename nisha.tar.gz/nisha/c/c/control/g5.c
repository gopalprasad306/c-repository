// 5)   Write a C program to print multiplication tables from 10 to 20.                                complete
#include<stdio.h>
main()
{
	int num=10,i;
	for(num;num<=20;num++)
	{
		for(i=1;i<=10;i++)
			printf("%d ",num*i);
		printf("\n");
	}
}
