// 3)   Write a C Program to reverse the digits of a given number.             complete
#include<stdio.h>
main()
{
	int num,num1=0;
	printf("enter number\n");
	scanf("%d",&num);
	for(num;num>0;num1=(num1*10)+num%10,num/=10);
	printf("reverse number is %d\n",num1);
}
