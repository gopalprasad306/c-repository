// 7)   Write a C program to print ArmStrong Numbers between 1 to 500.                                 complete
#include<stdio.h>
main()
{
	int num,num1,sum;
	for(num=1;num<=500;num++)
	{
		num1=num;
		sum=0;
		for(num1;num1;num1/=10)
			sum=sum+(num1%10)*(num1%10)*(num1%10);
		if(sum==num)
			printf("%d ",num);
	}
	printf("\n");
}//
