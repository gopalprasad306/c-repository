// 16)  Write a C program to print fibonacci series between 0 to 50.
#include<stdio.h>
main()
{
	int n1,n2,temp;
	printf("%d %d ",0,1);
	for(n1=0,n2=1;;)
	{
		temp=n2;
		n2=n1+n2;
		if(n2>=50)
			break;
		printf("%d ",n2);
		n1=temp;
	}
	printf("\n");
}
