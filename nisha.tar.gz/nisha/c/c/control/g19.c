/* 19)  Accept a month in digit from the user. Display the month in words. If number is not
        between 1 and 12 display message “Invalid Month”. (Use ‘switch’)
*/
#include<stdio.h>
main()
{
	int month;
	printf("enter month number in digit\n");
	scanf("%d",&month);
	switch(month)
	{
		case 1:
			printf("january\n");
			break;
		case 2:
			printf("febubary\n");
			break;
		case 3:
			printf("march\n");
			break;
		case 4:
			printf("aprail\n");
			break;
		case 5:
			printf("may\n");
			break;
		case 6:
			printf("june\n");
			break;
		case 7:
			printf("july\n");
			break;
		case 8:
			printf("august\n");
			break;
		case 9:
			printf("september\n");
			break;
		case 10:
			printf("octuber\n");
			break;
		case 11:
			printf("november\n");
			break;
		case 12:
			printf("december\n");
			break;
		default:
			printf("wrong option\n");
			break;
	}//
}
