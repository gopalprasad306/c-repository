// 2)   Write a C Program to Find the sum of digits of a given number.
#include<stdio.h>
main()
{
	int num,sum=0;
	printf("enter number\n");
	scanf("%d",&num);
	for(num;num>0;sum=sum+num%10,num/=10);
	printf("%d\n",sum);
}
