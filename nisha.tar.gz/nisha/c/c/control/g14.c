/* 14)  Write a C program to find the complement of a perticular bit. User has to take the
        position  number at runtime.
*/
#include<stdio.h>
main()
{
int num,n,i;
printf("enter a number\n");
scanf("%d",&num);
printf("enter a bit number which u want to comliment\n");
scanf("%d",&n);
for(i=31;i>=0;printf("%d",num>>i&1),i--);
printf("\n");
num=num^(1<<n);
for(i=31;i>=0;printf("%d",num>>i&1),i--);
printf("\n");
}
