// 4) Write a recursive function to revese the given number.
#include<stdio.h>
int reverse_num(int);
main()
{
	int num,res;
	printf("enter a number\n");
	scanf("%d",&num);
	res=reverse_num(num);
	printf("%d\n",res);
}
int reverse_num(int num)
{
	static int mul=0;
	if(num)
	{
		mul=mul*10+num%10;
		reverse_num(num/10);
	}
	else
		return mul;
}
