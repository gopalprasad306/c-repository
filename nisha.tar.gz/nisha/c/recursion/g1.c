// 1) Write a recursive function to find the factorial of a given number..
#include<stdio.h>
long long int factorial(int);
main()
{
	int num;
	long long int res;
	printf("enter a number\n");
	scanf("%d",&num);
	res=factorial(num);
	printf("factorial of %d  is %llu\n",num,res);

}
long long int factorial(int num)
{
	if(num==1)
		return 1;
	else
		return (num*factorial(num-1));
}
