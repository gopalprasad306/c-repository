/* 6) Write a recursive function that displays a positive integer in words. For ex: if the
   integer is 3412 then it is displayed as three four one two.
 */
#include<stdio.h>
char a[10][10]={"zero","one","two","three","four","five","six","seven","eight","nine"};
void display(int);
main()
{
	int num;
	printf("enter number\n");
	scanf("%d",&num);
	display(num);
	printf("\n");
}

void display(int num)
{
	if(num)
	{
		display(num/10);
		printf("%s ",a[num%10]);
	}
}
