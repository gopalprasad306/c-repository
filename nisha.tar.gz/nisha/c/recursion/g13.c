/*  13) Write a recursive function to revese the string. (Note : not just reverse printing
        charecter by charecter)
*/
#include<stdio.h>
#include<string.h>
void rev_string(char *,int,int);
void rev(char *p);
main()
{
	int l;
	char a[20];
	printf("enter a string\n");
	scanf("%s",a);
	l=strlen(a);
	rev_string(a,0,l-1);
	printf("%s\n",a);
} 
void rev_string(char *p,int i,int j)
{
	int temp;
	if(i<j)
	{
		temp=p[i];
		p[i]=p[j];
		p[j]=temp;
		rev_string(p,++i,--j);
	}
}

