// 7) Write a recursive function to print first 100 prime numbers.
#include<stdio.h>
void prime(int);
main()
{
	int num;
	printf("enter number\n");
	scanf("%d",&num);
	prime(num);
	printf("\n");
}
void prime(int num)
{
	static int count=0;
	int i;
	if(count<100)
	{
		for(i=2;i<num;i++)
			if(num%i==0)
				break;
		if(num==i)
		{
			count++;
			printf("%d ",num);
		}
		prime(num+1);
	}
}
