// reverse string using recursion
#include<stdio.h>
char * rev_string(char *);
char b[20];
static int i=0;
main()
{
	char a[20],*p;
	printf("enter a string\n");
	scanf("%s",a);
	p=rev_string(a);
	printf("%s\n",p);
}
char * rev_string(char *p)
{
	if(*p)
	{
		rev_string(p+1);
		b[i++]=*p;
	}
	return b;
}
