/* 5) Write a recursive function to that displays all the proper divisors of a given number
	 exept that and returns their sum.
	 Ex: 1,3,5,9,15 & 45 are the proper divisors of 45.
	        sum = 1+3+5+9+15
		      = 33 */
#include<stdio.h>
int divisor(int);
main()
{
	int num,res;
	printf("enter a number\n");
	scanf("%d",&num);
	res=divisor(num);
	printf("%d\n",res);
}

int divisor(int num)
{
	static number=0,sum=0;
	number++;
	if(number!=num)
	{
		if(num%number==0)
		{
			printf("%d ",number);
			sum=sum+number;
		}
		divisor(num);
	}
	else
	{
		printf("\n");
		return sum;
	}
}
