// 2) Write a recursive function to print the 'n'  fibonacci series numbers.
#include<stdio.h>
void fibonaci(int);
main()
{
	int n;
	printf("enter n number till that fibonaci will print\n");
	scanf("%d",&n);
	printf("%d %d ",0,1);
	fibonaci(n);
	printf("\n");
}

void fibonaci(int num)
{
	static int n1=0,n2=1;
	int temp;
	if(num>2)
	{
		temp=n2;
		n2=n1+n2;
		n1=temp;
		printf("%d ",n2);
		fibonaci(num-1);
	}
}
