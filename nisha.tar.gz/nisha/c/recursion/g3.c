// 3) Write a recursive function to find the sum of digits of a given number.
#include<stdio.h>
int sum_digit(int);
main()
{
	int num,res;
	printf("enter number \n");
	scanf("%d",&num);
	res=sum_digit(num);
	printf("%d\n",res);

}
int sum_digit(int num)
{
	if(num)
		return (num%10+sum_digit(num/10));

}
