//   10) Write a recursive function to find the largest element in a given Unsorted array.
#include<stdio.h>
int big_element(int *,int);
main()
{
int a[10],ele,i,big;
ele=sizeof(a)/sizeof(a[0]);
printf("enter %d element\n",ele);
for(i=0;i<ele;i++)
scanf("%d",a+i);
big=big_element(a+1,a[0]);
printf("big element is array is %d\n",big);
}
int big_element(int *p,int num)
{

}
