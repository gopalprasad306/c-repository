// wap to create 3 child who have different parent
#include"header.h"
main()
{
	if(fork()==0)
	{
		if(fork()==0)
		{
			if(fork()==0)
			{
//				printf("3 %d %d\n",getpid(),getppid());
				system("date");
			}
			else
			{
//				printf("2 %d %d\n",getpid(),getppid());
				sleep(6);
				system("cal");
			}
		}
		else
		{
//			printf("1 %d %d\n",getpid(),getppid());
			sleep(4);
			system("pwd");
		}
	}
	else
	{
//		printf("p %d %d\n",getpid(),getppid());
		sleep(8);
		system("ls");
		
	}
}
