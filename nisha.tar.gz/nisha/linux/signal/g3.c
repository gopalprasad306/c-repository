/*create a function named find isr which calling by passing an interrupt numberthen it should inform the action of that signal incurrent program.
signal action --- defaulted
o/p ignore
usrdefine
hint use signal() function to return value.
*/
#include"header.h"
void (*p)(int);
find_isr(int num)
{
	p=signal(num,SIG_DFL);
	if(p==SIG_IGN)
		printf("ignore\n");
	else if(p==SIG_DFL)
		printf("default\n");
	else
		printf("my_isr\n");
}
main()
{
	struct sigaction v;
	int no;
	printf("enter a interrupt number\n");
	scanf("%d",&no);
	v.sa_handler=SIG_IGN;
	sigemptyset(&v.sa_mask);
	v.sa_flags=0;
	sigaction(no,&v,0);
	find_isr(no);
}
