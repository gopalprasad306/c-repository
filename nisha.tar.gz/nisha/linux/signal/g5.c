/*write a program to ignore the termination of process when its terminal will close
*/
#include"header.h"
main()
{
printf("i love nisha %d \n",getpid());
signal(SIGHUP,SIG_IGN);
while(1);
}
