/* 
write a program to deliver the alarm signal periodically after n-1 sec from the last interrupt
*/
#include"header.h"
int num;
void my_isr(int n)
{
	printf("%d\n",num);
	num--;
	if(num==0)
		raise(9);
	else
		alarm(num);
}
main(int argc,char **argv)
{
	if(argc!=2)
	{
		printf("usage: plz give correct input\n");
		return;
	}
	signal(14,my_isr);
	num=atoi(argv[1]);
	alarm(num);
	while(1);
}
