/*write a program parent has to get data from user and store in file after that parent process will send signal one signal to child process after reciving signal open the file and convert data to oppsite case and store them again in file
*/
#include"header.h"
main()
{
int k;
if((k=fork())==0)
{
printf("%d\n",getpid());
int i;
char a[20];
printf("hello\n");
pause();
printf("hiii\n");
FILE *fp;
fp=fopen("nisha","r+");
if(fp==0)
{
perror("open");
return;
}
fgets(a,20,fp);
for(i=0;a[i];i++)
if(a[i]>='a'&&a[i]<='z')
a[i]=a[i]-32;
rewind(fp);
fputs(a,fp);
fclose(fp);
}
else
{
printf("%d\n",k);
char a[20];
FILE *fp;
fp=fopen("nisha","w");
if(fp==0)
{
perror("open");
return;
}
printf("enter a string\n");
scanf("%s",a);
fputs(a,fp);
kill(k,17);
perror("kill");
fclose(fp);
}
}//

