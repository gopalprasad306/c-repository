/*
write a program to create 3 child process from common parent use rando delay
between 1 to 10 sec in each child.use alarm in parenr is such a manner that
child 1 should not exceed more than 4 sec
child 2 should not exceed more than 6 sec
child 3 should not exceed more than 8 sec
*/
#include"header.h"
int a,b,c;
void my_isr1(int n)
{
int s,s1;
s=wait(0);
if(s==a)
{
if(WIFEXITED(s1))
printf("1st child normal termited\n");
else
printf("1st child killed\n");
}
if(s==b)
{
if(WIFEXITED(s1))
printf("2nd child normal termiated\n");
else
printf("2nd child is killed by signal\n");
}
if(s==c)
{
if(WIFEXITED(s1))
printf("3rd child normal termination\n");
else
printf("3rd child is killed by signal\n");
}
}
///////////////
void my_isr(int n)
{
static int count;
count++;
if(count==1)
{
kill(a,9);
alarm(2);
}
else if(count==2)
{
kill(b,9);
alarm(2);
}
else
{
kill(c,9);
alarm(2);
signal(14,SIG_DFL);
}
}

//////////////
main()
{
if((a=fork())==0)
{
int r;
srand(getpid());
r=rand()%10+1;
printf("1st %d\n",r);
sleep(r);
}
else
{
if((b=fork())==0)
{
int r;
srand(getpid());
r=rand()%10+1;
printf("2nd %d\n",r);
sleep(r);
}
else
{
if((c=fork())==0)
{
int r;
srand(getpid());
r=rand()%10+1;
printf("3rd %d\n",r);
sleep(r);
}
else
{
signal(14,my_isr);
signal(17,my_isr1);
alarm(4);
while(1);
}
}
}
}//





