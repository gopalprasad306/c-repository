//write a program to remove from zombie
#include"header.h"
main()
{
if(fork()==0)
{
printf("child %d %d\n",getpid(),getppid());
sleep(10);
}
else
{
struct sigaction v;
v.sa_handler=0;
sigemptyset(&v.sa_mask);
v.sa_flags=SA_NOCLDWAIT;
printf("%d %d\n",getpid(),getppid());
sigaction(SIGCHLD,&v,0);
while(1);
}
}//
