/* creat a watch dog timer in parent which should watch T.A.T of its child
and terminatethe child.
condition - the child have random delay (1-10)
if the child take more than 5 sec then parent termiante it.
hint : fork(),sleep(),kill(),alarm()
*/
#include"header.h"
int num2;
void my_isr(int n)
{
	kill(num2,9);
}

void my_isr1(int n)
{
	int s;
	if(WIFEXITED(s))
	{
		printf("normal termination of child\n");
		raise(9);
	}
	if(WIFSIGNALED(s))
	{
		printf("terminated by a signal\n");
		raise(9);
	}
}

main()
{
	int num;
	if((num=fork())==0)
	{
		int r;
		srand(getpid());
		r=rand()%10+1;
		printf("%d\n",r);
		sleep(r);
		exit(2);
	}
	else
	{
		signal(14,my_isr);
		signal(17,my_isr1);
		num2=num;
		alarm(5);
		while(1);
	}
}



