/* 
write a program to to install isr for sigint and sigquit.restore the sigint to default 3 times occurance,sigquit to default after 5 times occurance.
*/
#include"header.h"
void my_isr(int n)
{
	static num1,num2;
	if(n==2)
	{
		num1++;
		if(num1==2)
			signal(2,SIG_DFL);
	}
	if(n==3)
	{
		num2++;
		if(num2==4)
			signal(3,SIG_DFL);
	}
}
main()
{
	signal(2,my_isr);
	signal(3,my_isr);
	while(1);
}
