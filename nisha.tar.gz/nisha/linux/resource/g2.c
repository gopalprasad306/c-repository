// wap to know the soft and hard limit of core file.
#include"header.h"
main()
{
char *p;
*p=39;
struct rlimit v;
getrlimit(RLIMIT_CORE,&v);
printf("soft limit=%d\n",v.rlim_cur);
printf("hard limit=%d\n",v.rlim_max);
v.rlim_cur=100;
v.rlim_max=200;
setrlimit(RLIMIT_CORE,&v);
getrlimit(RLIMIT_CORE,&v);
printf("soft limit=%d\n",v.rlim_cur);
printf("hard limit=%d\n",v.rlim_max);
printf("%c\n",*p);
}
