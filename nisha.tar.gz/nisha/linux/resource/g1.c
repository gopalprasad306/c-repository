// WAP TO KNOW THE SIZE OF STSACK
#include"header.h"
main()
{
struct rlimit v;
getrlimit(RLIMIT_STACK,&v);
printf("soft limit =%d\n",v.rlim_cur);
printf("hard limit=%d\n",v.rlim_max);
v.rlim_cur=1000;
v.rlim_max=2000;
setrlimit(RLIMIT_STACK,&v);
printf("soft limit =%d\n",v.rlim_cur);
printf("hard limit=%d\n",v.rlim_max);
}
