// write  a program to compare the size of two files,input from command line
main(int argc,char **argv)
{
struct stat v,v1;
stat(argv[1],&v);
stat(argv[1],&v1);
if(v.st_size>v1.st_size)
printf("size of first file is greater\n");
else if(v.st_size<v1.st_size)
printf("size of first file is small\n");
else
printf("both file have equal size\n");
}
