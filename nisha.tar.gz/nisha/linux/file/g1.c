// wap a program to find the size of a file without opening the file
#include"header.h"
main(int argc,char **argv)
{
if (argc!=2)
{
printf("usage: plz give correct input\n");
return;
}
struct stat v;
stat(argv[1],&v);
printf("size of file is %d\n",v.st_size);
}
