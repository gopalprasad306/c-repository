// full duplex communication using fifo
#include"header.h"
main()
{
	int fd,fd1;
	char a[20],b[20];
	mkfifo("f1",0644);
	perror("mkfifo");
	mkfifo("f2",0644);
	perror("mkfifo");
	fd=open("f1",O_RDWR);
	fd1=open("f2",O_RDWR);
	if(fork()==0)
	{
		while(1)
		{
			read(fd,a,sizeof(a));
			printf("                        %s\n",a);
		}
	}
	else
	{
		while(1)
		{
			scanf(" %[^\n]",b);
			write(fd1,b,strlen(b)+1);
		}
	}
}//
