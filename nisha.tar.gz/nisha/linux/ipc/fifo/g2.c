// full duplex using fifo
#include"header.h"
main()
{
	char a[20],b[20];
	int fd,fd1;
	mkfifo("f1",0644);
	perror("mkfifo");
	mkfifo("f2",0644);
	perror("mkfifo");
	fd=open("f1",O_RDWR);
	fd1=open("f2",O_RDWR);
	if(fork()==0)
	{
		while(1)
		{
			read(fd1,a,sizeof(a));
			printf("                          %s\n",a);
		}
	}
	else
	{
		while(1)
		{
			scanf(" %[^\n]",a);
			write(fd,a,strlen(a)+1);
		}
	}
}//
