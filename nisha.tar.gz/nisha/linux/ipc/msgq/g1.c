// write a program for msgque
#include"header.h"
struct msgbuf
{
int mtype;
char data[20];
};
main(int argc,char **argv)
{
int id;
struct msgbuf v;
v.mtype=atoi(argv[1]);
strcpy(v.data,argv[2]);
id=msgget(5,IPC_CREAT|0644);
if(id<0)
{
perror("msgget");
return;
}
msgsnd(id,&v,sizeof(v),0);
perror("msgsnd");
}
