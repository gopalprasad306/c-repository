// revc program of msgq  g1.c and g2.c
#include"header.h"
struct msgbuf
{
int mtype;
char data[20];
};
main(int argc,char **argv)
{
int id;
struct msgbuf v;
id=msgget(5,IPC_CREAT|0644);
if(id<0)
{
perror("msgget");
return;
}
msgrcv(id,&v,sizeof(v),atoi(argv[1]),0);
perror("msgrcv");
printf("%s\n",v.data);
}
