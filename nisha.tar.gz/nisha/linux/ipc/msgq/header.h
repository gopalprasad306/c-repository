#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<signal.h>
#include<sys/time.h>
#include<sys/resource.h>
#include<sys/stat.h>
#define _GNU_SOURCE    
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#define MSG_EXCEPT 02 0000
