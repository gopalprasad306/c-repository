//  2nd program of assignment 
#include"header.h"
main()
{
	int p[2],num;
	char ch;
	if(pipe(p)<0)
	{
		perror("pipe");
		return;
	}
	if(fork()==0)
	{
		read(p[0],&num,sizeof(int));
		printf("num=%d\n",num);
		printf("enter a char\n");
		scanf("%c",&ch);
		write(p[1],&ch,sizeof(char));
	}
	else
	{
		printf("enter a number\n");
		scanf("%d",&num);
		write(p[1],&num,sizeof(int));
		sleep(1);
		read(p[0],&ch,sizeof(char));
		printf("char=%c\n",ch);
	}
}//
