// write  a program to send  a helloword in interconnected process
#include"header.h"
main()
{
char a[20];
int f[2];
if(pipe(f)<0)
{
perror("pipe");
return;
}
if(fork()==0)
{
read(f[0],a,sizeof(a));
printf("string is %s\n",a);
}
else
{
printf("enter a string\n");
scanf("%s",a);
write(f[1],a,strlen(a)+1);
}
}//
