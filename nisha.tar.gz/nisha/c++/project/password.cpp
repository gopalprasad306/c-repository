#include<iostream>
using namespace std;
void registeration(void)
{
int num,i;
string s;
char a[50];
cout<<"enter your name"<<endl;
getline(cin,s);
cout<<"enter your passowrd"<<end;
for(;;)
{
cin>>a;
if()
}
}

main()
{
int op;
printf("1) choose to register\n2) user verification\n 3) reset password\n");
scanf("%d",&op);
switch(op)
{
case 1:
registeration();

}
}//main
