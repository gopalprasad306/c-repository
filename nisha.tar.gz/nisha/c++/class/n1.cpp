#include<iostream>
using namespace std;
class B;
class A
{
	int x,y;
	public:
	A(){}  //deafault constructor

	A(int a,int b)   //parametiez constructor
	{
		x=a,y=b;
	}
	void display(void)
	{
		cout<<"x ="<<x<<" "<<"y ="<<y<<endl;
	}
	friend A add(A &obj,B &obj1);
};

class B
{
	int x,y;
	public:
	B(int a,int b)
	{
		x=a,y=b;
	}
	friend A add(A &obj,B &obj1);
};
A add(A &obj,B &obj1)  //non member function
{
	static A temp;
	temp.x=obj.x+obj1.x;
	temp.y=obj.y+obj1.y;
	return temp;
}
int main()
{
	A obj(10,20),obj1;
	B ob(30,40);
	obj1=add(obj,ob);
	obj1.display();
}




