#include<iostream>
using namespace std;
class A
{
	public:
		int a,b;
		A()
		{
			cout<<"class A constructor"<<endl;
		}
};
class B:private A
{
	public:
		int c,d;
		B(int x,int y,int z,int g):c(x),d(y)
	{
		a=z,b=g;
		cout<<"class B constructor"<<endl;
	}
		void displayB(void)
		{
			cout<<"a ="<<a<<" "<<"b ="<<b<<endl;
			cout<<"c ="<<c<<" "<<"d ="<<d<<endl;
		}
};
class C
{
	int e,f;
	public:
	C(int x,int y):e(x),f(y)
	{
		cout<<"Class C constructor"<<endl;
	}
	void displayC(void)
	{
		cout<<"e ="<<e<<" "<<"f ="<<f<<endl;
	}
};
class D:private B,private C
{
	int g,h;
	public:
	D(int z,int y,int x,int w,int v,int u,int t,int r):g(z),h(y),C(x,w),B(v,u,t,r)
	{
		cout<<"class D constructor"<<endl;
	}
	void displayD(void)
	{
		displayB();
		displayC();
		cout<<"g ="<<g<<" "<<"h ="<<h<<endl;
	}
};
main()
{
	D d(80,70,60,50,40,30,20,10);
	d.displayD();
}



