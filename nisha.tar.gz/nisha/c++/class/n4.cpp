#include<iostream>
#include<cstring>
using namespace std;
class Bank
{
	public:
		char name[20];
		int account_id,balance;
		float interest;
		virtual void display(void)=0;
		virtual void calculate_interest(void)=0;
};
class Saving:public Bank
{
	public:
		Saving(const char *p,int id,int money)
		{
			strcpy(name,p);
			account_id=id;
			balance=money;
		}
		void display(void)
		{
			cout<<"name ="<<name<<endl;
			cout<<"account_id ="<<account_id<<endl;
			cout<<"balance ="<<balance<<endl;
		}
		void calculate_interest(void)
		{
			interest=balance*1*4/100;
			cout<<"interest ="<<interest<<endl;
		}
};
class Current:public Bank
{
	public:
		Current(const char *p,int id,int money)
		{
			strcpy(name,p);
			account_id=id;
			balance=money;
		}
		void display(void)
		{
			cout<<"name ="<<name<<endl;
			cout<<"account_id ="<<account_id<<endl;
			cout<<"balance ="<<balance<<endl;
		}
		void calculate_interest(void)
		{
			interest=balance*1*5/100;
			cout<<"interest ="<<interest<<endl;
		}

};
main()
{
	Saving S("gopal",1147081,5000);
	Current C("nisha",1147073,10000);
		Bank *p;
	p=&S;
	p->display();
	p->calculate_interest();
	p=&C;
	p->display();
	p->calculate_interest();
}










