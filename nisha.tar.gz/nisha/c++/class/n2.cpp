#include<iostream>
using namespace std;
class A
{
	int a,b;
	public:
	A(int x,int y):a(x),b(y)
	{
		cout<<"class A constructor"<<endl;
	}
	void display(void)
	{
		cout<<"a ="<<a<<" "<<"b= "<<b<<endl;
	}
};
class B:public A
{
	int c,d;
	public:
	B(int x,int y,int z,int w):c(x),d(y),A(z,w)
	{
		cout<<"class B constructor"<<endl;
	}
	void display1(void)
	{
		display();
		cout<<"c ="<<c<<" "<<"d ="<<d<<endl;
	}
};
class C:public B
{
	int e,f;
	public:
	C(int x,int y,int z,int w,int m,int n):e(x),f(y),B(z,w,m,n)
	{
		cout<<"class C constructor"<<endl;
	}
	void display2(void)
	{
		display1();
		cout<<"e ="<<e<<" "<<"f ="<<f<<endl;
	}
};
main()
{
	C c(10,20,30,40,50,60);
	c.display2();
}






