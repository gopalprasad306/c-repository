#include<iostream>
using namespace std;
	template<class T> 
void swp(T &a,T &b)
{
	T temp;
	temp=a;
	a=b;
	b=temp;
}
main()
{
	int x,y;
	cout<<"enter two number"<<endl;
	cin>>x>>y;
	swp(x,y);
	cout<<"x ="<<x<<" "<<"y ="<<y<<endl;
}
