#include<iostream>
using namespace std;
template<class T1,typename T2>
class A
{
	public:
		T1 x;
		T2 y;
		void setdata(T1 a,T2 b)
		{
			x=a;
			y=b;
		}
		void display();
};
template<typename T1,typename T2>
void A<T1,T2>::display()
{
cout<<"x ="<<x<<endl<<"y ="<<y<<endl;
}
main()
{
	A<int,char> obj;
	obj.setdata(10,'A');
	obj.display();

}
