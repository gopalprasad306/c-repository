#include<iostream>
using namespace std;
	template<typename T1,typename T2>
void print(T1 &a,T2 &b)
{
	cout<<"a ="<<a<<" "<<"b ="<<b<<endl;
}
main()
{
	int x=10,y=20;
	char a='A',b='B';
	print(a,x);
	print(y,b);
}
