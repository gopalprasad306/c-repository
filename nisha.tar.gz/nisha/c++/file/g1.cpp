#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
main()
{
int len,i;
string ptr;
char str[10],ch;
fstream fin_out;
fin_out.open("gopal.txt",ios :: in | ios :: out | ios:: trunc);
cout<<"enter a string"<<endl;
cin>>str;
len=strlen(str);
for(i=0;i<len;i++)
fin_out.put(str[i]);
fin_out.seekg(0);
while(fin_out.good())
{
//fin_out.get(ch);
getline(fin_out,ptr);
cout<<str;
}
cout<<endl;
//fin_out.close();
}
