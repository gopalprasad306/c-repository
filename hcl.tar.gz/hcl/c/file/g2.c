// 2) Write a Program to remove a Specific line from the given text file
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
	int linenum,count=0;
	unsigned long long int lof;
	char *p,*q;
	FILE *FP;
	FP=fopen("file2","r+");
	if(FP==NULL)
	{
		printf("file open problem\n");
		return;
	}
	printf("enter line number\n");
	scanf("%d",&linenum);
	fseek(FP,0,2);
	lof=ftell(FP);
	rewind(FP);
	p=malloc(lof+1);
	q=malloc(lof+1);
	while((fgets(p,lof,FP))!=NULL)
	{
		count++;
		if(count!=linenum)
			strcat(q,p);
	}
	FP=fopen("file2","w");
	fputs(q,FP);
	fclose(FP);
}//main











