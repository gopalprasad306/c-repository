// 1) Write a Program to Convert Lower to Upper and Upper to Lower Cases of a given file.
#include<stdio.h>
main(int argc,char** argv)
{
	if(argc<2)
	{
		printf("please give proper input\n");
		return;
	}
	int ch;
	FILE *fp;
	fp=fopen(argv[1],"r+");
	if(fp==NULL)
		printf("there is a problen to open this file\n");
	while((ch=fgetc(fp))!=EOF)
	{
		if(ch>='a'&&ch<='z')
		{
			fseek(fp,-1,1);
			ch=ch-32;
                       printf("%c\n",ch);
			fputc(ch,fp);
		}
		else if(ch>='A'&&ch<='Z')
		{
			fseek(fp,-1,1);
			ch=ch+32;
			fputc(ch,fp);
		}
	}//while
	close(fp);
	printf("donec check file\n");
}//main
