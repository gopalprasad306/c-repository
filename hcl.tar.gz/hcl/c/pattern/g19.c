/*
2
3 4
4 5 6
5 6 7 8
6 7 8 9 10

*/
#include<stdio.h>
main()
{
	int num,i,j,n=1,n1;
	printf("enter a number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		n1=++n;
		for(j=0;j<=i;j++)
			printf("%d ",n1++);
		printf("\n");
	}
}//
