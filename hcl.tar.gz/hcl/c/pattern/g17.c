/*
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5

*/
#include<stdio.h>
main()
{
	int n,num=1,i,j;
	printf("enter a genric number to print pattern\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=i;j++)
			printf("%d ",num);
		num++;
		printf("\n");
	}
}//main
