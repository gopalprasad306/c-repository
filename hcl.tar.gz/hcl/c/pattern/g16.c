/*

*
* *
* * *
* * * *
* * * * *
* * * * * *

*/
#include<stdio.h>
main()
{
	int num,i,j;
	printf("enter a genric number to print pattern\n");
	scanf("%d",&num);
	for(i=1;i<=num;i++)
	{
		for(j=0;j<i;j++)
			printf("* ");
		printf("\n");
	}
}//main
