/*
1
0 1
1 0 1
0 1 0 1
1 0 1 0 1

*/
#include<stdio.h>
main()
{
int num,i,j;
printf("enter a genric num\n");
scanf("%d",&num);
for(i=0;i<num;i++)
{
for(j=i;j>=0;j--)
{
if(j%2)
printf("0 ");
else
printf("1 ");
}
printf("\n");
}
}//

