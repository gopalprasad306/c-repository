/*

A                       A
A B                   B A
A B C               C B A
A B C D           D C B A
A B C D E       E D C B A
A B C D E F   F E D C B A
A B C D E F G F E D C B A

6 5 4 3 2 1 0 1 2 3 4 5 6
*/

#include<stdio.h>
main()
{
	int num,num1,i,j;
	char ch;
	printf("enter a genric pattern number\n");
	scanf("%d",&num);
	num1=-num;
	for(i=0;i<=num;i++)
	{
		ch='A';
		for(j=-num;j<=num;j++)
		{
			if(j>num1&&j<-num1)
				printf("  ");
			else
			{
				if(j==0)      //in last iteration on j=0, this line execute 
					printf("%c ",ch);
				else if(j>0)
					printf("%c ",--ch);
				else
					printf("%c ",ch++);
			}
		}
		num1++;
		printf("\n");
	}

}//main

