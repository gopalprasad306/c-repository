/*
5
4 4
3 3 3 
2 2 2 2
1 1 1 1 1

*/
#include<stdio.h>
main()
{
	int num,i,j,n;
	printf("enter a number\n");
	scanf("%d",&num);
	n=num;
	for(i=0;i<num;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",n);
		n--;
		printf("\n");
	}

}//
