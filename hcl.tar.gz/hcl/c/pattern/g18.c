/*
1
1 2
1 2 3 
1 2 3 4
1 2 3 4 5

*/
#include<stdio.h>
main()
{
	int num,i,j,n;
	printf("enter a number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		n=1;
		for(j=0;j<=i;j++)
			printf("%d ",n++);
		printf("\n");
	}
}//main
