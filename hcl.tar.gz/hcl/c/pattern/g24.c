/*
6 5 4 3 2 1 0 1 2 3 4 5 6
A B C D E F G F E D C B A 
A B C D E F   F E D C B A
A B C D E       E D C B A 
A B C D           D C B A 
A B C               C B A
A B                   B A
A                       A

*/
#include<stdio.h>
main()
{
	char ch='A';
	int num,i,j;
	printf("enter a number\n");
	scanf("%d",&num);
	ch=ch+num;
	for(i=0;i<=num;i++)
	{
		for(j=-num;j<=num;j++)
		{
			if(-i<j&&i>j)                        // if(j>-i&&j<i)
				printf("  ");
			else
			{
				if(j<0)
					printf("%c ",ch+j);
				else
					printf("%c ",ch-j);
			}
		}
		printf("\n");
	}
}//main
