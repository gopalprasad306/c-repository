/*
5
5 4
5 4 3
5 4 3 2
5 4 3 2 1

*/
#include<stdio.h>
main()
{
	int num,i,j,n;
	printf("enter a number\n");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		n=num;
		for(j=0;j<=i;j++)
			printf("%d ",n--);
		printf("\n");
	}

}//
