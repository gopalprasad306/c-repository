// 4) Write a program to find vowels in a given  string.
#include<stdio.h>
main()
{
char a[50],p[50];int i,q,j=0;
printf("enter a string\n");
scanf("%[^\n]",a);
q=sizeof(p);
for(i=0;i<=q;i++)
p[i]='\0';
for(i=0;a[i];i++)
{
if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')
{
if(j==0)
p[j++]=a[i];
else
{
for(q=j-1;q>=0;q--)
if(a[i]!=p[q])
p[j++]=a[i];
}
}
}
p[j]='\0';
printf("%s\n",p);
}//main 
