// 3) Write a program to find the no.of times the character is found in a given string.
#include<stdio.h>
main()
{
char a[20],ch;
int i,count=0;
printf("enter a string\n");
scanf("%s",a);
printf("enter a character\n");
scanf(" %c",&ch);
for(i=0;a[i];i++)
if(a[i]==ch)
count++;
printf("%c is %d times in %s \n",ch,count,a);
}
