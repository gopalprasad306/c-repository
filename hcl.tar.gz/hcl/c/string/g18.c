/*18) Write a program to reverse the words in a given string line.
Ex : “I am a good boy”
“I ma a doog yob”
 */
#include<stdio.h>
main()
{
	char a[50];
	int i,j,space=0,temp,len;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(len=0;a[len];len++);
	for(i=0;i<=len;i++)
	{
		if(a[i]==' '||a[i]=='\0')
		{
			for(j=i-1,space;j>space;j--,space++)
			{
				temp=a[space];
				a[space]=a[j];
				a[j]=temp;
			}
			space=i+1;
		}
	}
	printf("%s\n",a);
}//main end
