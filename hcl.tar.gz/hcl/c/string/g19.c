/*
   19) Write a program to replace the words in reverse order in a given string line.
Ex:  Input   :  “world changed your thoughts”
Output :  “thoughts your changed world”
 */
#include<stdio.h>
main()
{
	char a[50];
	int i,j,space=0,temp,len,l;
	printf("enter a string\n");
	scanf("%[^\n]",a);
	for(len=0;a[len];len++);
	l=len;
	for(i=0,len=len-1;i<len;i++,len--)
	{
		temp=a[i];
		a[i]=a[len];
		a[len]=temp;
	}
	for(i=0;i<=l;i++)
	{
		if(a[i]==' '||a[i]=='\0')
		{
			for(j=i-1;j>space;j--,space++)
			{
				temp=a[j];
				a[j]=a[space];
				a[space]=temp;
			}
			space=i+1;
		}
	}
	printf("%s\n",a);

}//main
