// 1) Write a program to find  string length using pointer.
#include<stdio.h>
int str_len(const char *);
main()
{
	char a[20];
	int len;
	printf("enter a string\n");
	scanf("%s",a);
	len=str_len(a);
	printf("length of string is %d\n",len);
}
int str_len(const char *p)
{
	int i;
	for(i=0;*(p+i);i++);
	return i;
}
