// 2) Write a one line code to copy the string into another buffer.
#include<stdio.h>
main()
{
char a[20],b[20];int i;
printf("enter a string\n");
gets(a);
for(i=0;a[i];b[i]=a[i],i++);
printf("%s\n",b);
}
