// wap to remove digits and special char from string
#include<stdio.h>
main()
{
int i,j;
char a[30];
printf("enter a string\n");
scanf("%[^\n]",a);
for(i=0;a[i];i++)
{
if(!(a[i]>='a'&&a[i]<='z'))
{
j=i;
for(j;a[j];j++)
a[j]=a[j+1];
i--;
}
}
printf("%s\n",a);
}//main
