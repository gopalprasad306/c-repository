// wap to check a number is prime or not
#include<stdio.h>
int prime(int);
main()
{
	int num,ret;
	printf("enter a number\n");
	scanf("%d",&num);
	ret=prime(num);
	if(ret)
		printf("number is prime\n");
	else
		printf("number is not prime\n");

}
int prime(int num)
{
	int i;
	for(i=2;i<num;i++)
		if(!(num%i))
			break;
	if(i==num)
		return 1;
	else
		return 0;
}
