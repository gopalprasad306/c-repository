// five student name store
#include<stdio.h>
main()
{
char a[5][20];
int row,col,i,j;
row=sizeof(a)/sizeof(a[0]);
printf("enter %d student name\n",row);
for(i=0;i<row;i++)
scanf(" %[^\n]",a[i]);
for(i=0;i<row;i++)
printf("%s\n",a[i]);
}
