#include<stdio.h>
main()
{
char ch;
printf("enter a char\n");
scanf("%c",&ch);
if(ch>='a'&&ch<='z')
printf("small letter\n");
else if(ch>='A'&&ch<='Z')
printf("capital letter\n");
else if(ch>='0'&&ch<='9')
printf("digit\n");
else
printf("non\n");

}
