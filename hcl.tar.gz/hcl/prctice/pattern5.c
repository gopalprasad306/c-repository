/*   incomplete
    *
   * *
  * * *
 * * * *
* * * * *

*/
#include<stdio.h>
main()
{

}
