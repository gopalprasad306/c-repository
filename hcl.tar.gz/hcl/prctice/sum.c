#include<stdio.h>
main()
{
int num1,num2,sum;
printf("enter two number\n");
scanf("%d%d",&num1,&num2);
sum=num1+num2;
printf("sum is =%d\n",sum);
}
