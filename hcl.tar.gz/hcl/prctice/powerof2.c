// write a program to check power of any number is or not
#include<stdio.h>
main()
{
	int num,num1,num3;
	printf("enter two number\n");
	scanf("%d%d",&num,&num1);
	num3=num;
	for(num;num;num=num/num1)
	{
		if(num%num1)
			break;
		if(num==num1)
		{
			printf("%d is power of %d\n",num3,num1);
			break;
		}
	}
	if(num!=num1)
		printf("%d is not power of %d\n",num3,num1);
}
