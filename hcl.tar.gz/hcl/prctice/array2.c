// wap to find biggest array element in array
#include<stdio.h>
main()
{
int a[5],ele,i,big,small;
ele=sizeof(a)/sizeof(a[0]);
printf("enter %d element of array\n",ele);
for(i=0;i<ele;i++)
scanf("%d",a+i);
big=a[0];
small=a[0];
for(i=1;i<ele;i++)
{
if(a[i]>big)
big=a[i];
if(a[i]<small)
small=a[i];
}
printf("big ele =%d\nsmall ele =%d\n",big,small);
}//main
