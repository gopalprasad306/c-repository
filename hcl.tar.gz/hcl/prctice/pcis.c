// scan two char from user , where ever first char put another char beside that
#include<stdio.h>
#include<string.h>
main()
{
	char a[20],ch,ch1;
	int i,len;
	printf("enter a string\n");
	scanf("%s",a);
	printf("enter two char\n");
	scanf(" %c %c",&ch,&ch1);
	for(i=0;a[i];i++)
	{
		len=strlen(a);
		if(a[i]==ch)
		{
			for(len;len>i;len--)
				a[len+1]=a[len];
			a[len+1]=ch1;
		}
	}
	printf("%s\n",a);
}
