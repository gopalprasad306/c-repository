// wap to del a specified cahr from string
#include<stdio.h>
main()
{
	char a[20],ch,i,j;
	printf("enter a string\n");
	gets(a);
	printf("enter a char\n");
	scanf("%c",&ch);
	for(i=0;a[i];i++)
	{
		if(a[i]==ch)
		{
			for(j=i;a[j];j++)
				a[j]=a[j+1];
			i--;
		}
	}
	printf("%s\n",a);
}//main
