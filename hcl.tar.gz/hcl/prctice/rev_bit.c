// program to reverse the bits of a given number
#include<stdio.h>
main()
{
	int num,max_pos,init_pos;
	printf("enter a number\n");
	scanf("%d",&num);
	printf("before\n");
	for(max_pos=31;max_pos>=0;printf("%d",num>>max_pos&1),max_pos--);
	printf("\n");
	for(max_pos=31,init_pos=0;max_pos>init_pos;max_pos--,init_pos++)
		if((num>>max_pos&1)!=(num>>init_pos&1))
		{
			num=num^(1<<max_pos);
			num=num^(1<<init_pos);
		}
	printf("after\n");
	for(max_pos=31;max_pos>=0;printf("%d",num>>max_pos&1),max_pos--);
	printf("\n");
}//main
