// program to find 2nd biggest number among three   incomplete
#include<stdio.h>
main()
{
int num1,num2,num3;
printf("enter three number\n");
scanf("%d%d%d",&num1,&num2,&num3);
if(num1>num2)
{
if(num1<num3)
printf("2nd biggest =%d\n",num1);
else
printf("2nd biggest =%d\n",num3);
}
else
{
if(num2<num3)
printf("2nd biggest =%d\n",num2);
else
printf("2nd biggest =%d\n",num3);
}

}//main

