/*

*
* *
* * *
* * * *
* * * * *
*/
#include<stdio.h>
main()
{
	int num,init_val1,init_val2;
	printf("enter number for pattern\n");
	scanf("%d",&num);
	for(init_val1=0;init_val1<num;init_val1++)
	{
		for(init_val2=0;init_val2<=init_val1;init_val2++)
			printf("* ");
		printf("\n");
	}
}//main



















