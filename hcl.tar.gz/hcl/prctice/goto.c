// program to display binary format of a number using goto 
#include<stdio.h>
main()
{
int num,pos=31;
printf("enter a number\n");
scanf("%d",&num);
loop:
num>>pos&1?printf("1"):printf("0");
pos--;
if(pos>=0)
goto loop;
printf("\n");
}
