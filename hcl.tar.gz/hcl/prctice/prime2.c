#include<stdio.h>
main()
{
	int num,i_val;
	printf("enter a number\n");
	scanf("%d",&num);
	for(i_val=2;i_val<num;i_val++)
		if(num%i_val==0)
			break;
	if(num==i_val)
		printf("%d is a prime number\n",num);
	else
		printf("%d is not a prime number\n",num);
}
