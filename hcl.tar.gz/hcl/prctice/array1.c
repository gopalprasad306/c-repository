//wap to reverse print and reverse the element in array
#include<stdio.h>
main()
{
int a[10],ele,i,dup_ele,temp,j;
ele=sizeof(a)/sizeof(a[0]);
printf("enter %d element of array\n",ele);
for(i=0;i<ele;i++)
scanf("%d",a+i);
for(i=0;i<ele;i++)
printf("%d ",*(a+i));
printf("\nreverse print of array\n");
for(dup_ele=ele-1;dup_ele>=0;dup_ele--)
printf("%d ",*(a+dup_ele));
printf("\n");
for(i=0,j=ele-1;i<j;i++,j--)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}//main
