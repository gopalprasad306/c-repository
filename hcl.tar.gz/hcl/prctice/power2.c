// write a program to check number is power of 2 or not
#include<stdio.h>
main()
{
int num,i_val,count=0;
printf("enter a number\n");
scanf("%d",&num);
for(i_val=0;i_val<=31;i_val++)
{
if(num&(1<<i_val))
count++;
}
if(count==1)
printf("number is prime\n");
else
printf("number is not prime\n");
}
