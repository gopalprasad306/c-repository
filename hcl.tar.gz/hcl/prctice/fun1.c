// wap to create a function to print binary format of a num
#include<stdio.h>
int print_binary(int);
main()
{
	int num,count;
	printf("enter a number\n");
	scanf("%d",&num);
	count=print_binary(num);
	printf("above are binary format of %d\n",num);
	printf("total %d bits are set\n",count);
}
int print_binary(int num)
{
	int i,count=0;
	for(i=31;i>=0;i--)
	{
		if(num>>i&1)
			count++;
		printf("%d",num>>i&1);
	}
	printf("\n");
	return count;
	printf("\n");
}
