// write a program to check palimdrome number
#include<stdio.h>
main()
{
	int num,dup,sum;
	printf("palindrome numbers are \n");
	for(num=100;num<=200;num++)
	{
		sum=0;
		dup=num;
		for(dup;dup;sum=sum*10+dup%10,dup/=10);
		if(sum==num)
			printf("%d ",num);
	}
	printf("\n");
}
