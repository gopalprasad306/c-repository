// write a program to scan number a bit position from user and do set , clear a/c
#include<stdio.h>
main()
{
	int num,bit_pos,option,counter;
	printf("enter a number and a bit-pos \n");
	scanf("%d%d",&num,&bit_pos);
	printf("please select \n1) set a bit \n2) clear a bit \n3) compliment a bit\n");
	scanf("%d",&option);
	switch(option)
	{
		case 1:
			{
				printf("before\n");
				for(counter=31;counter>=0;counter--)
					printf("%d",num>>counter&1);
					printf("\n");
				if(num>>bit_pos&1)
				{
					printf("bit alredy set\n");
					break;
				}
				num=num|1<<bit_pos;
				printf("%d\n",num);
				for(counter=31;counter>=0;counter--)
					num&1<<counter?printf("1"):printf("0");
					printf("\n");
				break;
			}
		case 2:
			{
				printf("before\n");
				for(counter=31;counter>=0;counter--)
					printf("%d",num>>counter&1);
				printf("\n");
				if(!(num&(1<<bit_pos)))
				{
					printf("bit is alredy clear\n");
					break;
				}
				num=num&~(1<<bit_pos);
				printf("after \n");
				for(counter=31;counter>=0;counter--)
					printf("%d",num>>counter&1);
				printf("\n");
				break;
			}
case 3:
{
printf("before\n");
for(counter=31;counter>=0;counter--)
printf("%d",num>>counter&1);
printf("\n");
printf("after\n");
num=num^1<<bit_pos;
for(counter=31;counter>=0;counter--)
printf("%d",num>>counter&1);
printf("\n");
break;
}
default:
printf("wrong option\n");
}// switch end

}// main end














