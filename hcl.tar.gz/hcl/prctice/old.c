#include<stdio.h>
main()
{
char ch,ch1;
printf("enter two char\n");
scanf("%c %c",&ch,&ch1);
printf("%c%c\n",ch,ch1);
}
