// write a program to check number is armstrom number
#include<stdio.h>
main()
{
	int num,dup,sum;
	for(num=1;num<=1000;num++)
	{
		sum=0;
		dup=num;
		for(dup;dup;dup/=10)
			sum=sum+(dup%10)*(dup%10)*(dup%10);
		if(sum==num)
			printf("%d ",num);
	}
	printf("\n");
}
