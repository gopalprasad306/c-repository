/*
* * * * *
 * * * *
  * * *
   * *
    *
*/
#include<stdio.h>
main()
{
int genric_num,init1,init2;
printf("enter genric_num\n");
scanf("%d",&genric_num);
for(init1=0;init1<genric_num;printf("\n"),init1++)
{
for(init2=0;init2<init1;printf(" "),init2++);
for(init2=0;init2<genric_num-init1;printf("* "),init2++);
}
}//main
