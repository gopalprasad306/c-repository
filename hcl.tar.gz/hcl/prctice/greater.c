// programto find greatest number among three number
#include<stdio.h>
main()
{
	int num1,num2,num3;
	printf("enter three number\n");
	scanf("%d%d%d",&num1,&num2,&num3);
	if(num1>num2)
	{
		if(num1>num3)
			printf("biggest number =%d\n",num1);
		else
			printf("biggest number =%d\n",num3);
	}
	else
	{
		if(num2>num3)
			printf("biggest number =%d\n",num2);
		else
			printf("biggest number =%d\n",num3);

	}

}//main
