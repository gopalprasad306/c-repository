#include<stdio.h>
main()
{
	unsigned long long int fac_num;
	int num;
	printf("enter a number\n");
	scanf("%d",&num);
	printf("size of num=%d\n",sizeof(fac_num));
	for(fac_num=1;num;num--)
	{
		fac_num*=num;
	}
	printf("factorial =%llu\n",fac_num);
}

