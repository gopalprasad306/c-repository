/*
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
*/
#include<stdio.h>
main()
{
	int genric_number,num=1,init1,init2;
	printf("enter genric number \n");
	scanf("%d",&genric_number);
	for(init1=0;init1<genric_number;num=1,printf("\n"),init1++)
		for(init2=0;init2<=init1;printf("%d ",num++),init2++);
	//		printf("%d ",num++);
}//main
