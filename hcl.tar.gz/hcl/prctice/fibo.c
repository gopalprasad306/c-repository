#include<stdio.h>
main()
{
	int num1,num2,temp,count;
	printf("enter num1 and num2\n");
	scanf("%d%d",&num1,&num2);
	printf("%d %d ",num1,num2);
	for(count=1;count<=10;count++)
	{
		temp=num2;
		printf("%d ",num2=num1+num2);
		num1=temp;
	}
	printf("\n");
}
