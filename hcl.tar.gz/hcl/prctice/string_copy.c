// wap to copy string from source to destination string
#include<stdio.h>
main()
{
char source[10],desti[10],i;
printf("enter a source string\n");
scanf("%s",source);
for(i=0;source[i];i++);
printf("length of string is %d\n",i);
for(i=0;source[i];i++)
desti[i]=source[i];
desti[i]=source[i];
printf("soutce =%s\ndestination =%s\n",source,desti);
}
