// wap to find prime numbers in array
#include<stdio.h>
main()
{
	int a[5],ele,i,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("enter %d number\n",ele);
	for(i=0;i<ele;i++)
		scanf("%d",a+i);
	for(i=0;i<ele;i++)
		printf("%d\t",*(a+i));
	printf("\nbelow are prime numbers\n");
	for(i=0;i<ele;i++)
	{
		for(j=2;j<a[i];j++)
			if(!(a[i]%j))
				break;
		if(a[i]==j)
			printf("%d\t",a[i]);
	}
	printf("\n");
}//main
