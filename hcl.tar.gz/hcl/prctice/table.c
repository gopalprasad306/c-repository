#include<stdio.h>
main()
{
int num,init_val;
printf("enter a number\n");
scanf("%d",&num);
for(init_val=1;init_val<=10;init_val++)
printf("%d * %d  =  %d\n",num,init_val,num*init_val);
}
