//write a program to add the digit of a number
#include<stdio.h>
main()
{
int num,sum=0;
printf("enter a number\n");
scanf("%d",&num);
for(;num;sum=sum+num%10,num/=10);
printf("sum = %d\n",sum);
}
