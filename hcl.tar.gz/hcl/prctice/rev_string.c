// wap to reverse that string
#include<stdio.h>
main()
{
char a[10],i,j,temp;
printf("enter a string\n");
scanf("%s",a);
for(j=0;a[j];j++);
for(i=0,j=j-1;i<j;i++,j--)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
printf("%s\n",a);
}
