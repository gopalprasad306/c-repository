// write a program to reverse a number
#include<stdio.h>
main()
{
int num,rev_num=0;
printf("enter a number\n");
scanf("%d",&num);
for(;num;rev_num=rev_num*10+num%10,num/=10);
printf("reverse number is %d\n",rev_num);
}
