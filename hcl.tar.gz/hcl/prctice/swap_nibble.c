// program to swap the nibble
#include<stdio.h>
main()
{
int init_pos,mid_pos,high_pos;
char ch;
printf("enter a character\n");
scanf("%c",&ch);
printf("before\n");
for(high_pos=7;high_pos>=0;printf("%d",ch>>high_pos&1),high_pos--);
printf("\n");
for(init_pos=0,mid_pos=4;init_pos<4;init_pos++,mid_pos++)
if((ch>>mid_pos)!=(ch>>init_pos))
{
ch=ch^(1<<mid_pos);
ch=ch^(1<<init_pos);
}
printf("after\n");
for(high_pos=7;high_pos>=0;printf("%d",ch>>high_pos&1),high_pos--);
printf("\n");

}//
